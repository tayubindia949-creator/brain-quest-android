<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/8eb0978c-6b37-469c-91ef-e02c0a97a8e6

## Run Locally

**Prerequisites:**  [Android Studio](https://developer.android.com/studio)


1. Open Android Studio
2. Select **Open** and choose the directory containing this project
3. Allow Android Studio to fix any incompatibilities as it imports the project.
4. Create a file named `.env` in the project directory and set `GEMINI_API_KEY` in that file to your Gemini API key (see `.env.example` for an example)
5. Remove this line from the app's `build.gradle.kts` file: `signingConfig = signingConfigs.getByName("debugConfig")`
6. Run the app on an emulator or physical device
7. If you have already published your app in AI Studio, please [request upload key reset](https://support.google.com/googleplay/android-developer/answer/9842756#zippy=%2Crequest-an-upload-key-reset) in Google Play Console.


## AdMob test banner integration

This project now includes the Google Mobile Ads Android SDK and a bottom anchored adaptive **test** banner. It intentionally uses Google's official sample App ID and banner ad unit ID. These are test IDs only and do not generate revenue. Before publishing, replace them with the App ID and banner ad unit ID created in the publisher's own AdMob account, and complete the applicable AdMob app review/setup. Do not click test ads.

- App ID is declared in `app/src/main/AndroidManifest.xml` under `com.google.android.gms.ads.APPLICATION_ID`.
- Banner ad unit ID is in `app/src/main/java/com/example/ad/AdMobBanner.kt`.
- The current rewarded-ad controller remains a no-op; rewarded ads have not yet been connected.
