package com.example.ad

/**
 * Rewarded-ad abstraction retained for the game's hint/reward flow.
 * The current integration adds a Google test banner; rewarded ads are not wired yet.
 */
interface AdRewardController {
    val isAdsEnabled: Boolean
    fun preloadRewardedAd()
}

class NoOpAdRewardController : AdRewardController {
    override val isAdsEnabled: Boolean = false
    override fun preloadRewardedAd() {
        // Rewarded placement will be connected after the publisher's AdMob IDs are supplied.
    }
}
