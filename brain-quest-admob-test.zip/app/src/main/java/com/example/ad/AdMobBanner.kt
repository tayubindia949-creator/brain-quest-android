package com.example.ad

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView

/** Google-provided test banner. Replace with the app's own ad unit before release. */
@Composable
fun AdMobTestBanner(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val screenWidth = LocalConfiguration.current.screenWidthDp
    val adView = remember(context, screenWidth) {
        AdView(context).apply {
            adUnitId = TEST_BANNER_AD_UNIT_ID
            setAdSize(AdSize.getLargeAnchoredAdaptiveBannerAdSize(context, screenWidth))
            loadAd(AdRequest.Builder().build())
        }
    }

    AndroidView(
        modifier = modifier,
        factory = { adView }
    )

    DisposableEffect(adView) {
        onDispose { adView.destroy() }
    }
}

private const val TEST_BANNER_AD_UNIT_ID = "ca-app-pub-3940256099942544/9214589741"
