# Add project specific ProGuard rules here.
# Preserve line numbers and source file names for crash diagnostics.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# Room persistence entities and DAOs
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-dontwarn androidx.room.paging.**

# Future AdMob integration keep rules (uncomment when Google Mobile Ads SDK is added)
# -keep public class com.google.android.gms.ads.** { public *; }
# -keep public class com.google.ads.** { public *; }
