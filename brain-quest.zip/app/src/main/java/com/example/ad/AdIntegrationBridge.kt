package com.example.ad

/**
 * Clean abstraction layer reserved for future Google AdMob integration.
 * No advertising SDK or ad placements are currently active in this build.
 *
 * When ready to integrate AdMob:
 * 1. Add `com.google.android.gms:play-services-ads` in `libs.versions.toml` and `app/build.gradle.kts`.
 * 2. Declare `com.google.android.gms.ads.APPLICATION_ID` in `AndroidManifest.xml`.
 * 3. Provide an `AdMobRewardedAdController` implementing [AdRewardController].
 */
interface AdRewardController {
    val isAdsEnabled: Boolean
    fun preloadRewardedAd()
}

class NoOpAdRewardController : AdRewardController {
    override val isAdsEnabled: Boolean = false
    override fun preloadRewardedAd() {
        // Intentionally no-op while ads are disabled.
    }
}
