package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Immutable
data class GamePalette(
    val isDark: Boolean,
    val canvasTop: Color,
    val canvasBottom: Color,
    val cardSurface: Color,
    val tileSurface: Color,
    val tileBorder: Color,
    val gold: Color,
    val goldContainer: Color,
    val cyan: Color,
    val cyanContainer: Color,
    val violet: Color,
    val violetContainer: Color,
    val emerald: Color,
    val emeraldContainer: Color,
    val coral: Color,
    val coralContainer: Color,
    val starInactive: Color
)

private val DarkGamePalette = GamePalette(
    isDark = true,
    canvasTop = DeepIndigo900,
    canvasBottom = Color(0xFF121636),
    cardSurface = DeepIndigo800,
    tileSurface = DeepIndigo700,
    tileBorder = Color(0xFF343F7A),
    gold = AmberGold,
    goldContainer = Color(0xFF3A2D0B),
    cyan = ElectricCyan,
    cyanContainer = Color(0xFF0C3547),
    violet = SoftViolet,
    violetContainer = Color(0xFF2B2252),
    emerald = EmeraldSuccess,
    emeraldContainer = Color(0xFF0D382C),
    coral = CoralError,
    coralContainer = Color(0xFF471A27),
    starInactive = Color(0xFF384173)
)

private val LightGamePalette = GamePalette(
    isDark = false,
    canvasTop = ParchmentBg,
    canvasBottom = Color(0xFFE7ECF7),
    cardSurface = ParchmentCard,
    tileSurface = ParchmentElevated,
    tileBorder = Color(0xFFCFD8EC),
    gold = WarmGoldAccent,
    goldContainer = Color(0xFFFEF3C7),
    cyan = DeepTealAccent,
    cyanContainer = Color(0xFFE0F2FE),
    violet = Color(0xFF7C3AED),
    violetContainer = Color(0xFFEDE9FE),
    emerald = Color(0xFF059669),
    emeraldContainer = Color(0xFFD1FAE5),
    coral = Color(0xFFE11D48),
    coralContainer = Color(0xFFFFE4E6),
    starInactive = Color(0xFFD0D8EA)
)

val LocalGamePalette = staticCompositionLocalOf { DarkGamePalette }

private val DarkColorScheme = darkColorScheme(
    primary = AmberGold,
    onPrimary = Color(0xFF1E1600),
    primaryContainer = Color(0xFF4B3700),
    onPrimaryContainer = AmberGoldLight,
    secondary = ElectricCyan,
    onSecondary = Color(0xFF002730),
    secondaryContainer = Color(0xFF0B3A4A),
    onSecondaryContainer = Color(0xFFA5F3FC),
    tertiary = SoftViolet,
    onTertiary = Color(0xFF1F1240),
    background = DeepIndigo900,
    onBackground = IvoryText,
    surface = DeepIndigo800,
    onSurface = IvoryText,
    surfaceVariant = DeepIndigo700,
    onSurfaceVariant = MutedLavender,
    outline = Color(0xFF3C4782),
    error = CoralError,
    onError = Color(0xFF3B0613)
)

private val LightColorScheme = lightColorScheme(
    primary = RoyalIndigo,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDFE4FF),
    onPrimaryContainer = Color(0xFF141B52),
    secondary = DeepTealAccent,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE0F2FE),
    onSecondaryContainer = Color(0xFF075985),
    tertiary = Color(0xFF7C3AED),
    onTertiary = Color.White,
    background = ParchmentBg,
    onBackground = DeepNavyText,
    surface = ParchmentCard,
    onSurface = DeepNavyText,
    surfaceVariant = ParchmentElevated,
    onSurfaceVariant = SlateMuted,
    outline = Color(0xFFCBD5E1),
    error = Color(0xFFE11D48),
    onError = Color.White
)

private val BrainQuestShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun BrainQuestTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val gamePalette = if (darkTheme) DarkGamePalette else LightGamePalette

    CompositionLocalProvider(LocalGamePalette provides gamePalette) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = BrainQuestTypography,
            shapes = BrainQuestShapes,
            content = content
        )
    }
}
