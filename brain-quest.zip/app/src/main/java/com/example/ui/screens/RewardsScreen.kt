package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CardGiftcard
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.PlayerProgressSnapshot
import com.example.domain.model.AchievementBadge
import com.example.domain.model.MilestoneReward
import com.example.domain.model.RewardCatalog
import com.example.ui.components.CurrencyPillBar
import com.example.ui.components.TactilePrimaryButton
import com.example.ui.theme.LocalGamePalette

@Composable
fun RewardsScreen(
    snapshot: PlayerProgressSnapshot,
    onClaimMilestone: (String) -> Unit,
    onBuyHintPack: () -> Unit,
    onPlayDailyChallenge: () -> Unit,
    onBack: () -> Unit
) {
    val palette = LocalGamePalette.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 640.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("rewards_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Back to Home"
                        )
                    }
                    Text(
                        text = "Rewards & Mastery",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                CurrencyPillBar(
                    coins = snapshot.profile.coins,
                    stars = snapshot.totalStars,
                    hints = snapshot.profile.hintsRemaining,
                    onHintPackClick = onBuyHintPack
                )
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Daily Streak Card
                item {
                    Surface(
                        shape = RoundedCornerShape(22.dp),
                        color = palette.cardSurface,
                        border = BorderStroke(1.5.dp, palette.cyan.copy(alpha = 0.6f))
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Rounded.LocalFireDepartment,
                                        contentDescription = null,
                                        tint = palette.gold,
                                        modifier = Modifier.size(26.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = "Daily Challenge Streak",
                                            style = MaterialTheme.typography.titleMedium,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = "${snapshot.profile.dailyStreak} day(s) • ${snapshot.dailyHistory.count { it.completed }} total completed",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                            TactilePrimaryButton(
                                text = if (snapshot.todayDailyCompleted) "Replay Today's Trial" else "Play Today's Trial (+80 Coins)",
                                icon = Icons.Rounded.PlayArrow,
                                onClick = onPlayDailyChallenge,
                                containerColor = if (snapshot.todayDailyCompleted) palette.emerald else palette.cyan,
                                contentColor = Color(0xFF001F28),
                                modifier = Modifier.fillMaxWidth(),
                                testTag = "rewards_daily_button"
                            )
                        }
                    }
                }

                // Star Milestone Chests
                item {
                    Text(
                        text = "Star Milestone Chests",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                items(RewardCatalog.milestones, key = { it.id }) { milestone ->
                    val isClaimed = milestone.id in snapshot.claimedRewardIds
                    val isReady = snapshot.totalStars >= milestone.requiredStars && !isClaimed
                    MilestoneChestCard(
                        milestone = milestone,
                        currentStars = snapshot.totalStars,
                        isClaimed = isClaimed,
                        isReady = isReady,
                        onClaim = { onClaimMilestone(milestone.id) }
                    )
                }

                // Achievement Badges
                item {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Explorer Badges",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                items(snapshot.badges, key = { it.id }) { badge ->
                    AchievementBadgeCard(badge = badge)
                }
            }
        }
    }
}

@Composable
private fun MilestoneChestCard(
    milestone: MilestoneReward,
    currentStars: Int,
    isClaimed: Boolean,
    isReady: Boolean,
    onClaim: () -> Unit
) {
    val palette = LocalGamePalette.current
    val progress = (currentStars.toFloat() / milestone.requiredStars).coerceIn(0f, 1f)

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = palette.cardSurface,
        border = BorderStroke(
            width = if (isReady) 2.dp else 1.dp,
            color = when {
                isReady -> palette.gold
                isClaimed -> palette.emerald.copy(alpha = 0.6f)
                else -> palette.tileBorder
            }
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = when {
                    isClaimed -> palette.emeraldContainer
                    isReady -> palette.goldContainer
                    else -> palette.tileSurface
                }
            ) {
                Box(modifier = Modifier.padding(12.dp)) {
                    Icon(
                        imageVector = if (isClaimed) Icons.Rounded.CheckCircle else Icons.Rounded.CardGiftcard,
                        contentDescription = null,
                        tint = when {
                            isClaimed -> palette.emerald
                            isReady -> palette.gold
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = milestone.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "${milestone.description} • +${milestone.coinReward} Coins, +${milestone.hintReward} Hints",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(50)),
                    color = if (isClaimed) palette.emerald else palette.gold,
                    trackColor = palette.tileSurface
                )
            }

            if (isReady) {
                Button(
                    onClick = onClaim,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("claim_milestone_${milestone.id}"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = palette.gold,
                        contentColor = Color(0xFF1A1400)
                    ),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text("Claim", fontWeight = FontWeight.Bold)
                }
            } else {
                Text(
                    text = if (isClaimed) "Claimed" else "${currentStars}/${milestone.requiredStars}★",
                    style = MaterialTheme.typography.labelLarge,
                    color = if (isClaimed) palette.emerald else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun AchievementBadgeCard(badge: AchievementBadge) {
    val palette = LocalGamePalette.current
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = palette.cardSurface,
        border = BorderStroke(
            1.dp,
            if (badge.isUnlocked) palette.gold.copy(alpha = 0.65f) else palette.tileBorder
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (badge.isUnlocked) palette.goldContainer else palette.tileSurface
            ) {
                Box(modifier = Modifier.padding(10.dp)) {
                    Icon(
                        imageVector = if (badge.isUnlocked) Icons.Rounded.EmojiEvents else Icons.Rounded.Lock,
                        contentDescription = null,
                        tint = if (badge.isUnlocked) palette.gold else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = badge.title,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = badge.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                text = if (badge.isUnlocked) "Unlocked" else badge.progressLabel,
                style = MaterialTheme.typography.labelLarge,
                color = if (badge.isUnlocked) palette.emerald else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
