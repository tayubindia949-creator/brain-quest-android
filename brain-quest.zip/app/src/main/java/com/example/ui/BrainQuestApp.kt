package com.example.ui

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.components.SettingsDialog
import com.example.ui.components.StarfieldBackdrop
import com.example.ui.screens.GameScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LevelSelectScreen
import com.example.ui.screens.RewardsScreen
import com.example.ui.theme.BrainQuestTheme
import com.example.ui.viewmodel.GameHubViewModel
import com.example.ui.viewmodel.HubUiState

object BrainQuestRoutes {
    const val HOME = "home"
    const val LEVEL_SELECT = "level_select"
    const val GAME = "game"
    const val REWARDS = "rewards"
}

@Composable
fun BrainQuestApp(
    viewModel: GameHubViewModel,
    navController: NavHostController = rememberNavController()
) {
    val hubState by viewModel.hubState.collectAsStateWithLifecycle()
    val selectedRealm by viewModel.selectedRealm.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategoryFilter.collectAsStateWithLifecycle()
    val activeGame by viewModel.activeGame.collectAsStateWithLifecycle()
    val statusToast by viewModel.statusToast.collectAsStateWithLifecycle()

    var showSettings by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(statusToast) {
        val message = statusToast
        if (message != null) {
            snackbarHostState.showSnackbar(message)
            viewModel.clearStatusToast()
        }
    }

    val darkTheme = when (val state = hubState) {
        is HubUiState.Ready -> state.snapshot.profile.darkThemeEnabled
        HubUiState.Loading -> true
    }

    BrainQuestTheme(darkTheme = darkTheme) {
        StarfieldBackdrop {
            when (val state = hubState) {
                HubUiState.Loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
                is HubUiState.Ready -> {
                    val snapshot = state.snapshot
                    NavHost(
                        navController = navController,
                        startDestination = BrainQuestRoutes.HOME,
                        enterTransition = { fadeIn() },
                        exitTransition = { fadeOut() }
                    ) {
                        composable(BrainQuestRoutes.HOME) {
                            HomeScreen(
                                snapshot = snapshot,
                                onContinueQuest = { levelId ->
                                    viewModel.startLevel(levelId)
                                    navController.navigate(BrainQuestRoutes.GAME)
                                },
                                onOpenLevelSelect = {
                                    navController.navigate(BrainQuestRoutes.LEVEL_SELECT)
                                },
                                onStartDailyChallenge = {
                                    viewModel.startDailyChallenge()
                                    navController.navigate(BrainQuestRoutes.GAME)
                                },
                                onOpenRewards = {
                                    navController.navigate(BrainQuestRoutes.REWARDS)
                                },
                                onOpenSettings = { showSettings = true }
                            )
                        }

                        composable(BrainQuestRoutes.LEVEL_SELECT) {
                            LevelSelectScreen(
                                snapshot = snapshot,
                                selectedRealm = selectedRealm,
                                selectedCategory = selectedCategory,
                                onSelectRealm = viewModel::selectRealm,
                                onSelectCategory = viewModel::selectCategoryFilter,
                                onSelectLevel = { levelId ->
                                    viewModel.startLevel(levelId)
                                    navController.navigate(BrainQuestRoutes.GAME)
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(BrainQuestRoutes.GAME) {
                            val game = activeGame
                            if (game != null) {
                                GameScreen(
                                    gameState = game,
                                    profile = snapshot.profile,
                                    onPause = viewModel::pausePuzzle,
                                    onResume = viewModel::resumePuzzle,
                                    onRestart = viewModel::restartCurrentPuzzle,
                                    onExit = {
                                        viewModel.exitPuzzle()
                                        navController.popBackStack()
                                    },
                                    onNextLevel = viewModel::startLevel,
                                    onUseHint = viewModel::requestHint,
                                    onToggleBeacon = viewModel::onToggleBeaconCell,
                                    onSelectOption = viewModel::onSelectOptionAnswer,
                                    onSelectMagicCell = viewModel::onSelectMagicCell,
                                    onEnterMagicNumber = viewModel::onEnterMagicNumber,
                                    onClearMagicCell = viewModel::onClearMagicCell,
                                    onTapMemoryMatrix = viewModel::onTapMemoryMatrixCell,
                                    onTapMemorySequence = viewModel::onTapMemorySequencePad,
                                    onToggleSound = viewModel::toggleSound,
                                    onToggleHaptics = viewModel::toggleHaptics
                                )
                            } else {
                                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    CircularProgressIndicator()
                                }
                            }
                        }

                        composable(BrainQuestRoutes.REWARDS) {
                            RewardsScreen(
                                snapshot = snapshot,
                                onClaimMilestone = viewModel::claimMilestone,
                                onBuyHintPack = viewModel::buyHintPack,
                                onPlayDailyChallenge = {
                                    viewModel.startDailyChallenge()
                                    navController.navigate(BrainQuestRoutes.GAME)
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }

                    if (showSettings) {
                        SettingsDialog(
                            soundEnabled = snapshot.profile.soundEnabled,
                            hapticsEnabled = snapshot.profile.hapticsEnabled,
                            darkThemeEnabled = snapshot.profile.darkThemeEnabled,
                            onToggleSound = viewModel::toggleSound,
                            onToggleHaptics = viewModel::toggleHaptics,
                            onToggleDarkTheme = viewModel::toggleDarkTheme,
                            onBuyHintPack = viewModel::buyHintPack,
                            onDismiss = { showSettings = false }
                        )
                    }
                }
            }

            SnackbarHost(
                hostState = snackbarHostState,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 72.dp, start = 16.dp, end = 16.dp)
            )
        }
    }
}
