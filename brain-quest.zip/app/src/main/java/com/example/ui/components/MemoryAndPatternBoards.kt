package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.HelpOutline
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.PuzzleContent
import com.example.ui.theme.LocalGamePalette
import com.example.ui.viewmodel.ActiveGameState
import com.example.ui.viewmodel.MemoryPhase

@Composable
fun MemoryMatrixBoard(
    content: PuzzleContent.MemoryMatrix,
    state: ActiveGameState,
    onTapCell: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalGamePalette.current
    val isPreview = state.memoryPhase == MemoryPhase.PREVIEW
    val livesLeft = (content.maxMistakes - state.mistakesMade).coerceAtLeast(0)

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(50),
                color = if (isPreview) palette.goldContainer else palette.violetContainer,
                border = BorderStroke(1.dp, if (isPreview) palette.gold else palette.violet)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (isPreview) Icons.Rounded.Visibility else Icons.Rounded.AutoAwesome,
                        contentDescription = null,
                        tint = if (isPreview) palette.gold else palette.violet,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isPreview) "Memorize Constellation..." else "Tap ${content.targetIndices.size - state.foundMemoryIndices.size} more",
                        style = MaterialTheme.typography.labelLarge,
                        color = if (isPreview) palette.gold else palette.violet
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                repeat(content.maxMistakes) { idx ->
                    Icon(
                        imageVector = if (idx < livesLeft) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        contentDescription = "Life",
                        tint = if (idx < livesLeft) palette.coral else palette.starInactive,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 360.dp),
            contentAlignment = Alignment.Center
        ) {
            val boardWidth = minOf(maxWidth, 340.dp)
            Column(
                modifier = Modifier.width(boardWidth),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                for (r in 0 until content.gridSize) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        for (c in 0 until content.gridSize) {
                            val idx = r * content.gridSize + c
                            val isTarget = idx in content.targetIndices
                            val isFound = idx in state.foundMemoryIndices
                            val isHint = idx == state.hintMemoryIndex
                            val isWrong = idx == state.wrongMemoryIndex

                            val showLit = (isPreview && isTarget) || isFound
                            val bg by animateColorAsState(
                                targetValue = when {
                                    isFound -> palette.emeraldContainer
                                    isPreview && isTarget -> palette.goldContainer
                                    isHint -> palette.goldContainer.copy(alpha = 0.65f)
                                    isWrong -> palette.coralContainer
                                    else -> palette.tileSurface
                                },
                                label = "mem_cell_$idx"
                            )
                            val borderColor = when {
                                isFound -> palette.emerald
                                isPreview && isTarget -> palette.gold
                                isHint -> palette.gold
                                isWrong -> palette.coral
                                else -> palette.tileBorder
                            }
                            val scale by animateFloatAsState(
                                targetValue = if (showLit) 1.03f else 1f,
                                animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                                label = "mem_scale_$idx"
                            )

                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .aspectRatio(1f)
                                    .scale(scale)
                                    .minimumInteractiveComponentSize()
                                    .testTag("memory_cell_$idx")
                                    .clip(RoundedCornerShape(16.dp))
                                    .clickable(enabled = !isPreview && !isFound) { onTapCell(idx) },
                                shape = RoundedCornerShape(16.dp),
                                color = bg,
                                border = BorderStroke(if (showLit || isHint) 2.5.dp else 1.5.dp, borderColor)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    if (showLit || isHint) {
                                        Icon(
                                            imageVector = Icons.Rounded.AutoAwesome,
                                            contentDescription = "Memory star",
                                            tint = if (isFound) palette.emerald else palette.gold,
                                            modifier = Modifier.size(if (content.gridSize == 3) 30.dp else 24.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MemorySequenceBoard(
    content: PuzzleContent.MemorySequence,
    state: ActiveGameState,
    onTapPad: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalGamePalette.current
    val isPreview = state.memoryPhase == MemoryPhase.PREVIEW
    val padPalette = listOf(palette.gold, palette.cyan, palette.violet, palette.emerald, palette.coral)
    val columns = if (content.padCount <= 4) 2 else 3
    val rows = (content.padCount + columns - 1) / columns

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = if (isPreview) {
                "Watch the rune sequence closely..."
            } else {
                "Repeat the sequence (${state.sequenceProgressIndex}/${content.sequence.size})"
            },
            style = MaterialTheme.typography.titleMedium,
            color = if (isPreview) palette.gold else palette.cyan,
            textAlign = TextAlign.Center
        )

        // Step progress dots
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            repeat(content.sequence.size) { step ->
                val done = step < state.sequenceProgressIndex
                Surface(
                    shape = CircleShape,
                    color = if (done) palette.emerald else palette.tileSurface,
                    border = BorderStroke(1.dp, if (done) palette.emerald else palette.tileBorder),
                    modifier = Modifier.size(12.dp)
                ) {}
            }
        }

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 350.dp),
            contentAlignment = Alignment.Center
        ) {
            val boardWidth = minOf(maxWidth, 330.dp)
            Column(
                modifier = Modifier.width(boardWidth),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                for (r in 0 until rows) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        for (c in 0 until columns) {
                            val padIdx = r * columns + c
                            if (padIdx < content.padCount) {
                                val accent = padPalette[padIdx % padPalette.size]
                                val isFlashing = state.activeFlashPad == padIdx
                                val bg by animateColorAsState(
                                    targetValue = if (isFlashing) accent else palette.tileSurface,
                                    label = "seq_pad_$padIdx"
                                )
                                val scale by animateFloatAsState(
                                    targetValue = if (isFlashing) 1.06f else 1f,
                                    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                                    label = "seq_pad_scale_$padIdx"
                                )

                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .aspectRatio(1f)
                                        .scale(scale)
                                        .minimumInteractiveComponentSize()
                                        .testTag("sequence_pad_$padIdx")
                                        .clip(RoundedCornerShape(18.dp))
                                        .clickable(enabled = !isPreview) { onTapPad(padIdx) },
                                    shape = RoundedCornerShape(18.dp),
                                    color = bg,
                                    border = BorderStroke(2.dp, accent.copy(alpha = if (isFlashing) 1f else 0.55f)),
                                    shadowElevation = if (isFlashing) 10.dp else 2.dp
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = "${padIdx + 1}",
                                            style = MaterialTheme.typography.headlineSmall,
                                            color = if (isFlashing) palette.canvasTop else accent,
                                            fontWeight = FontWeight.ExtraBold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PatternVisualBoard(
    content: PuzzleContent.PatternVisual,
    state: ActiveGameState,
    onSelectOption: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalGamePalette.current
    val rows = (content.cells.size + content.columns - 1) / content.columns

    Column(
        modifier = modifier
            .fillMaxWidth()
            .widthIn(max = 540.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = content.prompt,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
        )

        Surface(
            shape = RoundedCornerShape(22.dp),
            color = palette.cardSurface,
            border = BorderStroke(1.dp, palette.tileBorder),
            modifier = Modifier.widthIn(max = if (content.columns == 4) 360.dp else 310.dp)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                for (r in 0 until rows) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        for (c in 0 until content.columns) {
                            val idx = r * content.columns + c
                            val glyph = content.cells.getOrNull(idx)
                            val isMissing = glyph == null
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .aspectRatio(1f),
                                shape = RoundedCornerShape(14.dp),
                                color = if (isMissing) palette.goldContainer else palette.tileSurface,
                                border = BorderStroke(
                                    width = if (isMissing) 2.dp else 1.dp,
                                    color = if (isMissing) palette.gold else palette.tileBorder
                                )
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(6.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (glyph != null) {
                                        PatternGlyphCanvas(
                                            glyph = glyph,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    } else if (state.selectedOptionIndex != null) {
                                        PatternGlyphCanvas(
                                            glyph = content.options[state.selectedOptionIndex],
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    } else {
                                        Icon(
                                            imageVector = Icons.Rounded.HelpOutline,
                                            contentDescription = "Missing pattern tile",
                                            tint = palette.gold,
                                            modifier = Modifier.size(28.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        Text(
            text = "Choose the matching glyph:",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            content.options.forEachIndexed { idx, optionGlyph ->
                val isEliminated = idx in state.eliminatedOptionIndices
                val isSelected = state.selectedOptionIndex == idx
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .aspectRatio(1f)
                        .minimumInteractiveComponentSize()
                        .testTag("option_button_$idx")
                        .clip(RoundedCornerShape(16.dp))
                        .clickable(enabled = !isEliminated) { onSelectOption(idx) },
                    shape = RoundedCornerShape(16.dp),
                    color = when {
                        isSelected -> palette.emeraldContainer
                        isEliminated -> palette.coralContainer.copy(alpha = 0.35f)
                        else -> palette.tileSurface
                    },
                    border = BorderStroke(
                        width = if (isSelected) 2.dp else 1.5.dp,
                        color = when {
                            isSelected -> palette.emerald
                            isEliminated -> palette.coral.copy(alpha = 0.35f)
                            else -> palette.tileBorder
                        }
                    )
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isEliminated) {
                            Text(
                                text = "✕",
                                fontSize = 22.sp,
                                color = palette.coral.copy(alpha = 0.7f),
                                fontWeight = FontWeight.Bold
                            )
                        } else {
                            PatternGlyphCanvas(
                                glyph = optionGlyph,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }
            }
        }
    }
}
