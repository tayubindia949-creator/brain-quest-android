package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import com.example.ui.theme.LocalGamePalette
import kotlin.math.PI
import kotlin.math.sin

private data class StarNode(
    val xFrac: Float,
    val yFrac: Float,
    val radiusDp: Float,
    val phase: Float
)

@Composable
fun StarfieldBackdrop(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val palette = LocalGamePalette.current
    val stars = remember {
        listOf(
            StarNode(0.12f, 0.09f, 1.8f, 0.0f),
            StarNode(0.28f, 0.17f, 1.2f, 1.1f),
            StarNode(0.74f, 0.07f, 2.0f, 2.2f),
            StarNode(0.88f, 0.21f, 1.5f, 0.6f),
            StarNode(0.18f, 0.42f, 1.4f, 2.8f),
            StarNode(0.82f, 0.49f, 1.9f, 1.7f),
            StarNode(0.41f, 0.63f, 1.3f, 0.4f),
            StarNode(0.14f, 0.78f, 1.7f, 2.5f),
            StarNode(0.69f, 0.84f, 2.1f, 1.3f),
            StarNode(0.91f, 0.72f, 1.2f, 3.0f),
            StarNode(0.54f, 0.29f, 1.5f, 1.9f),
            StarNode(0.32f, 0.91f, 1.6f, 0.9f)
        )
    }

    val transition = rememberInfiniteTransition(label = "starfield")
    val pulse by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 7000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "star_pulse"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(palette.canvasTop, palette.canvasBottom)
                )
            )
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Soft atmospheric glow orbs
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        palette.cyan.copy(alpha = if (palette.isDark) 0.11f else 0.08f),
                        palette.cyan.copy(alpha = 0f)
                    ),
                    center = Offset(w * 0.85f, h * 0.15f),
                    radius = w * 0.55f
                ),
                center = Offset(w * 0.85f, h * 0.15f),
                radius = w * 0.55f
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        palette.violet.copy(alpha = if (palette.isDark) 0.10f else 0.06f),
                        palette.violet.copy(alpha = 0f)
                    ),
                    center = Offset(w * 0.15f, h * 0.75f),
                    radius = w * 0.6f
                ),
                center = Offset(w * 0.15f, h * 0.75f),
                radius = w * 0.6f
            )

            // Subtle constellation lines
            if (stars.size >= 4) {
                val lineColor = palette.gold.copy(alpha = if (palette.isDark) 0.08f else 0.09f)
                drawLine(
                    color = lineColor,
                    start = Offset(w * stars[0].xFrac, h * stars[0].yFrac),
                    end = Offset(w * stars[1].xFrac, h * stars[1].yFrac),
                    strokeWidth = 1.5f
                )
                drawLine(
                    color = lineColor,
                    start = Offset(w * stars[2].xFrac, h * stars[2].yFrac),
                    end = Offset(w * stars[3].xFrac, h * stars[3].yFrac),
                    strokeWidth = 1.5f
                )
            }

            // Twinkling stars
            for (star in stars) {
                val alpha = 0.22f + 0.38f * ((sin(pulse + star.phase) + 1f) / 2f)
                drawCircle(
                    color = (if (star.phase > 1.5f) palette.cyan else palette.gold)
                        .copy(alpha = if (palette.isDark) alpha else alpha * 0.55f),
                    radius = star.radiusDp * density,
                    center = Offset(w * star.xFrac, h * star.yFrac)
                )
            }
        }
        content()
    }
}
