package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.automirrored.rounded.ExitToApp
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.MonetizationOn
import androidx.compose.material.icons.rounded.PauseCircle
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.data.local.LevelCompletionOutcome
import com.example.domain.model.PuzzleLevel
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalGamePalette

@Composable
fun PauseOverlay(
    level: PuzzleLevel,
    elapsedSeconds: Int,
    soundEnabled: Boolean,
    hapticsEnabled: Boolean,
    onToggleSound: (Boolean) -> Unit,
    onToggleHaptics: (Boolean) -> Unit,
    onResume: () -> Unit,
    onRestart: () -> Unit,
    onExit: () -> Unit
) {
    val palette = LocalGamePalette.current
    Dialog(
        onDismissRequest = onResume,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.65f))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 420.dp)
                    .testTag("pause_dialog"),
                shape = RoundedCornerShape(28.dp),
                color = palette.cardSurface,
                border = BorderStroke(1.5.dp, palette.tileBorder),
                shadowElevation = 16.dp
            ) {
                Column(
                    modifier = Modifier
                        .verticalScroll(rememberScrollState())
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.PauseCircle,
                        contentDescription = null,
                        tint = palette.gold,
                        modifier = Modifier.size(44.dp)
                    )
                    Text(
                        text = "Quest Paused",
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = if (level.isDailyChallenge) {
                            "${level.title} • ${formatTime(elapsedSeconds)}"
                        } else {
                            "Level ${level.id}: ${level.title} • ${formatTime(elapsedSeconds)}"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )

                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = palette.tileSurface
                    ) {
                        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                            SettingToggleRow(
                                icon = Icons.AutoMirrored.Rounded.VolumeUp,
                                label = "Sound Effects",
                                checked = soundEnabled,
                                onCheckedChange = onToggleSound,
                                testTag = "pause_sound_switch"
                            )
                            SettingToggleRow(
                                icon = Icons.Rounded.Vibration,
                                label = "Haptic Feedback",
                                checked = hapticsEnabled,
                                onCheckedChange = onToggleHaptics,
                                testTag = "pause_haptics_switch"
                            )
                        }
                    }

                    TactilePrimaryButton(
                        text = "Resume Quest",
                        icon = Icons.Rounded.PlayArrow,
                        onClick = onResume,
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "pause_resume_button"
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = onRestart,
                            modifier = Modifier
                                .weight(1f)
                                .minimumInteractiveComponentSize()
                                .testTag("pause_restart_button"),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Restart")
                        }
                        OutlinedButton(
                            onClick = onExit,
                            modifier = Modifier
                                .weight(1f)
                                .minimumInteractiveComponentSize()
                                .testTag("pause_exit_button"),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Rounded.ExitToApp, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Exit")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun VictoryOverlay(
    level: PuzzleLevel,
    outcome: LevelCompletionOutcome,
    elapsedSeconds: Int,
    onNextLevel: (() -> Unit)?,
    onReplay: () -> Unit,
    onExit: () -> Unit
) {
    val palette = LocalGamePalette.current
    Dialog(
        onDismissRequest = onExit,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.72f))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 420.dp)
                    .testTag("victory_dialog"),
                shape = RoundedCornerShape(28.dp),
                color = palette.cardSurface,
                border = BorderStroke(2.dp, palette.gold.copy(alpha = 0.7f)),
                shadowElevation = 20.dp
            ) {
                Column(
                    modifier = Modifier
                        .verticalScroll(rememberScrollState())
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_victory_crest),
                        contentDescription = "Victory crest",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(96.dp)
                            .clip(RoundedCornerShape(24.dp))
                    )

                    Text(
                        text = if (level.isDailyChallenge) "Daily Trial Complete!" else "Level ${level.id} Cleared!",
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center
                    )

                    StarRatingRow(
                        stars = outcome.starsEarned,
                        starSize = 36.dp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        StatTile(
                            label = "Score",
                            value = outcome.score.toString(),
                            accent = palette.cyan,
                            modifier = Modifier.weight(1f)
                        )
                        StatTile(
                            label = "Time",
                            value = formatTime(elapsedSeconds),
                            accent = palette.violet,
                            modifier = Modifier.weight(1f)
                        )
                        StatTile(
                            label = "Coins",
                            value = "+${outcome.coinsEarned}",
                            accent = palette.gold,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    if (outcome.hintsEarned > 0) {
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = palette.cyanContainer
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Rounded.Lightbulb, contentDescription = null, tint = palette.cyan, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "+${outcome.hintsEarned} Bonus Hint Earned!",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = palette.cyan
                                )
                            }
                        }
                    }

                    if (onNextLevel != null) {
                        TactilePrimaryButton(
                            text = "Next Level",
                            icon = Icons.AutoMirrored.Rounded.ArrowForward,
                            onClick = onNextLevel,
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "victory_next_button"
                        )
                    } else {
                        TactilePrimaryButton(
                            text = "Back to Adventure",
                            icon = Icons.AutoMirrored.Rounded.ExitToApp,
                            onClick = onExit,
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "victory_exit_primary_button"
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        TextButton(
                            onClick = onReplay,
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("victory_replay_button")
                        ) {
                            Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Replay")
                        }
                        TextButton(
                            onClick = onExit,
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("victory_map_button")
                        ) {
                            Text("Level Map")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FailureOverlay(
    message: String,
    onRetry: () -> Unit,
    onExit: () -> Unit
) {
    val palette = LocalGamePalette.current
    Dialog(
        onDismissRequest = onRetry,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.7f))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 400.dp)
                    .testTag("failure_dialog"),
                shape = RoundedCornerShape(28.dp),
                color = palette.cardSurface,
                border = BorderStroke(1.5.dp, palette.coral)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "Almost There!",
                        style = MaterialTheme.typography.headlineSmall,
                        color = palette.coral
                    )
                    Text(
                        text = message,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                    TactilePrimaryButton(
                        text = "Try Again",
                        icon = Icons.Rounded.Refresh,
                        onClick = onRetry,
                        containerColor = palette.cyan,
                        contentColor = Color(0xFF002029),
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "failure_retry_button"
                    )
                    TextButton(
                        onClick = onExit,
                        modifier = Modifier.minimumInteractiveComponentSize().testTag("failure_exit_button")
                    ) {
                        Text("Back to Map")
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsDialog(
    soundEnabled: Boolean,
    hapticsEnabled: Boolean,
    darkThemeEnabled: Boolean,
    onToggleSound: (Boolean) -> Unit,
    onToggleHaptics: (Boolean) -> Unit,
    onToggleDarkTheme: (Boolean) -> Unit,
    onBuyHintPack: () -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalGamePalette.current
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 420.dp)
                .testTag("settings_dialog"),
            shape = RoundedCornerShape(26.dp),
            color = palette.cardSurface,
            border = BorderStroke(1.dp, palette.tileBorder)
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(22.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Quest Settings",
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                SettingToggleRow(
                    icon = Icons.AutoMirrored.Rounded.VolumeUp,
                    label = "Sound Effects",
                    checked = soundEnabled,
                    onCheckedChange = onToggleSound,
                    testTag = "settings_sound_switch"
                )
                SettingToggleRow(
                    icon = Icons.Rounded.Vibration,
                    label = "Haptic Feedback",
                    checked = hapticsEnabled,
                    onCheckedChange = onToggleHaptics,
                    testTag = "settings_haptics_switch"
                )
                SettingToggleRow(
                    icon = Icons.Rounded.DarkMode,
                    label = "Midnight Observatory Theme",
                    checked = darkThemeEnabled,
                    onCheckedChange = onToggleDarkTheme,
                    testTag = "settings_theme_switch"
                )

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = palette.goldContainer,
                    border = BorderStroke(1.dp, palette.gold.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Hint Pack (+3 Hints)",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "60 Coins • Offline Shop",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = palette.gold,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("buy_hint_pack_button")
                        ) {
                            TextButton(onClick = onBuyHintPack) {
                                Icon(Icons.Rounded.MonetizationOn, contentDescription = null, tint = Color(0xFF1A1400), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("60", color = Color(0xFF1A1400), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Text(
                    text = "100% offline • No account or personal data required",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss, modifier = Modifier.minimumInteractiveComponentSize()) {
                        Text("Close")
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingToggleRow(
    icon: ImageVector,
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = LocalGamePalette.current.cyan,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(testTag)
        )
    }
}

@Composable
private fun StatTile(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = LocalGamePalette.current.tileSurface
    ) {
        Column(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = accent
            )
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

fun formatTime(seconds: Int): String {
    val m = seconds / 60
    val s = seconds % 60
    return "%02d:%02d".format(m, s)
}
