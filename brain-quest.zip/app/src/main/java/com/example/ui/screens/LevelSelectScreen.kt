package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.LevelProgressEntity
import com.example.data.local.PlayerProgressSnapshot
import com.example.domain.generator.PuzzleCatalog
import com.example.domain.model.PuzzleCategory
import com.example.domain.model.PuzzleLevel
import com.example.domain.model.Realm
import com.example.ui.components.CurrencyPillBar
import com.example.ui.components.StarRatingRow
import com.example.ui.components.categoryIcon
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalGamePalette

@Composable
fun LevelSelectScreen(
    snapshot: PlayerProgressSnapshot,
    selectedRealm: Realm,
    selectedCategory: PuzzleCategory?,
    onSelectRealm: (Realm) -> Unit,
    onSelectCategory: (PuzzleCategory?) -> Unit,
    onSelectLevel: (Int) -> Unit,
    onBack: () -> Unit
) {
    val palette = LocalGamePalette.current
    val realmLevels = PuzzleCatalog.allLevels.filter { level ->
        level.realm == selectedRealm && (selectedCategory == null || level.category == selectedCategory)
    }
    val realmStars = selectedRealm.levelRange.sumOf { id ->
        snapshot.levelStates[id]?.bestStars ?: 0
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp)
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("levels_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Back to Home"
                        )
                    }
                    Text(
                        text = "Adventure Map",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                CurrencyPillBar(
                    coins = snapshot.profile.coins,
                    stars = snapshot.totalStars,
                    hints = snapshot.profile.hintsRemaining
                )
            }

            // Realm Horizontal Selector
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Realm.entries.forEach { realm ->
                    val isSelected = realm == selectedRealm
                    val starsInRealm = realm.levelRange.sumOf { snapshot.levelStates[it]?.bestStars ?: 0 }
                    Surface(
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("realm_tab_${realm.index}")
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { onSelectRealm(realm) },
                        shape = RoundedCornerShape(16.dp),
                        color = if (isSelected) palette.goldContainer else palette.tileSurface,
                        border = BorderStroke(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) palette.gold else palette.tileBorder
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                        ) {
                            Text(
                                text = "Realm ${realm.index} (${realm.levelRange.first}–${realm.levelRange.last})",
                                style = MaterialTheme.typography.labelLarge,
                                color = if (isSelected) palette.gold else MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "${realm.title} • $starsInRealm/60 ★",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Category Filter Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedCategory == null,
                    onClick = { onSelectCategory(null) },
                    label = { Text("All") },
                    modifier = Modifier.testTag("filter_all"),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = palette.cyanContainer,
                        selectedLabelColor = palette.cyan
                    )
                )
                PuzzleCategory.entries.forEach { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { onSelectCategory(if (selectedCategory == cat) null else cat) },
                        label = { Text(cat.displayName) },
                        leadingIcon = {
                            Icon(
                                imageVector = categoryIcon(cat),
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        modifier = Modifier.testTag("filter_${cat.name.lowercase()}"),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = palette.cyanContainer,
                            selectedLabelColor = palette.cyan
                        )
                    )
                }
            }

            // Responsive Level Grid
            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                val columns = when {
                    maxWidth >= 600.dp -> 5
                    maxWidth >= 420.dp -> 4
                    else -> 3
                }

                LazyVerticalGrid(
                    columns = GridCells.Fixed(columns),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    item(span = { GridItemSpan(columns) }) {
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = palette.cardSurface,
                            border = BorderStroke(1.dp, palette.tileBorder)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = selectedRealm.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = selectedRealm.subtitle,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    text = "$realmStars / 60 ★",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = palette.gold
                                )
                            }
                        }
                    }

                    items(realmLevels, key = { it.id }) { level ->
                        val progress = snapshot.levelStates[level.id]
                        LevelNodeCard(
                            level = level,
                            progress = progress,
                            isCurrentFrontier = level.id == snapshot.highestUnlockedLevel,
                            onClick = { onSelectLevel(level.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LevelNodeCard(
    level: PuzzleLevel,
    progress: LevelProgressEntity?,
    isCurrentFrontier: Boolean,
    onClick: () -> Unit
) {
    val palette = LocalGamePalette.current
    val isUnlocked = progress?.isUnlocked == true || level.id == 1
    val isCompleted = progress?.isCompleted == true
    val stars = progress?.bestStars ?: 0

    val accent = when (level.category) {
        PuzzleCategory.LOGIC -> palette.cyan
        PuzzleCategory.NUMBER -> palette.gold
        PuzzleCategory.MEMORY -> palette.violet
        PuzzleCategory.PATTERN -> palette.emerald
    }

    val borderColor = when {
        isCurrentFrontier -> palette.gold
        isCompleted -> accent.copy(alpha = 0.7f)
        isUnlocked -> palette.tileBorder
        else -> palette.tileBorder.copy(alpha = 0.35f)
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.92f)
            .minimumInteractiveComponentSize()
            .testTag("level_node_${level.id}")
            .clip(RoundedCornerShape(18.dp))
            .clickable(enabled = isUnlocked, onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        color = when {
            isCurrentFrontier -> palette.goldContainer.copy(alpha = 0.75f)
            isUnlocked -> palette.cardSurface
            else -> palette.tileSurface.copy(alpha = 0.45f)
        },
        border = BorderStroke(if (isCurrentFrontier) 2.dp else 1.2.dp, borderColor)
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = categoryIcon(level.category),
                    contentDescription = level.category.displayName,
                    tint = if (isUnlocked) accent else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                    modifier = Modifier.size(15.dp)
                )
                if (!isUnlocked) {
                    Icon(
                        imageVector = Icons.Rounded.Lock,
                        contentDescription = "Locked",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.size(14.dp)
                    )
                } else if (isCurrentFrontier && !isCompleted) {
                    Icon(
                        imageVector = Icons.Rounded.PlayArrow,
                        contentDescription = "Play next",
                        tint = palette.gold,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Text(
                text = level.id.toString(),
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 22.sp,
                color = if (isUnlocked) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
            )

            Text(
                text = level.title,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            if (isUnlocked) {
                StarRatingRow(stars = stars, starSize = 14.dp)
            } else {
                Spacer(modifier = Modifier.height(14.dp))
            }
        }
    }
}
