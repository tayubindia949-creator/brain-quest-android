package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.ad.AdRewardController
import com.example.audio.SoundCue
import com.example.audio.SoundEffectManager
import com.example.data.local.BrainQuestRepository
import com.example.data.local.LevelCompletionOutcome
import com.example.data.local.PlayerProgressSnapshot
import com.example.domain.generator.LogicPuzzleBank
import com.example.domain.generator.PuzzleCatalog
import com.example.domain.model.PuzzleCategory
import com.example.domain.model.PuzzleContent
import com.example.domain.model.PuzzleLevel
import com.example.domain.model.Realm
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface HubUiState {
    data object Loading : HubUiState
    data class Ready(val snapshot: PlayerProgressSnapshot) : HubUiState
}

enum class MemoryPhase {
    PREVIEW,
    RECALL
}

data class ActiveGameState(
    val level: PuzzleLevel,
    val elapsedSeconds: Int = 0,
    val movesUsed: Int = 0,
    val mistakesMade: Int = 0,
    val hintsUsed: Int = 0,
    val isPaused: Boolean = false,
    val isFailed: Boolean = false,
    val outcome: LevelCompletionOutcome? = null,
    val hintMessage: String? = null,
    val feedbackBanner: String? = null,
    // LogicGridToggle
    val beaconLit: List<Boolean> = emptyList(),
    val remainingOptimalMoves: Set<Int> = emptySet(),
    val highlightedHintCell: Int? = null,
    // Option-based puzzles (LogicDeduction, NumberSequence, PatternVisual)
    val eliminatedOptionIndices: Set<Int> = emptySet(),
    val selectedOptionIndex: Int? = null,
    // NumberMagicGrid
    val magicCells: List<Int?> = emptyList(),
    val selectedMagicCellIndex: Int? = null,
    // MemoryMatrix & MemorySequence
    val memoryPhase: MemoryPhase = MemoryPhase.PREVIEW,
    val foundMemoryIndices: Set<Int> = emptySet(),
    val wrongMemoryIndex: Int? = null,
    val hintMemoryIndex: Int? = null,
    val activeFlashPad: Int? = null,
    val sequenceProgressIndex: Int = 0
)

class GameHubViewModel(
    private val repository: BrainQuestRepository,
    private val soundManager: SoundEffectManager,
    private val adController: AdRewardController
) : ViewModel() {

    val hubState: StateFlow<HubUiState> = repository.observeSnapshot()
        .onEach { snapshot ->
            soundManager.isEnabled = snapshot.profile.soundEnabled
        }
        .map<PlayerProgressSnapshot, HubUiState> { HubUiState.Ready(it) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = HubUiState.Loading
        )

    private val _selectedRealm = MutableStateFlow(Realm.WHISPERING_WOODS)
    val selectedRealm: StateFlow<Realm> = _selectedRealm.asStateFlow()

    private val _selectedCategoryFilter = MutableStateFlow<PuzzleCategory?>(null)
    val selectedCategoryFilter: StateFlow<PuzzleCategory?> = _selectedCategoryFilter.asStateFlow()

    private val _activeGame = MutableStateFlow<ActiveGameState?>(null)
    val activeGame: StateFlow<ActiveGameState?> = _activeGame.asStateFlow()

    private val _statusToast = MutableStateFlow<String?>(null)
    val statusToast: StateFlow<String?> = _statusToast.asStateFlow()

    private var timerJob: Job? = null
    private var memoryPreviewJob: Job? = null

    init {
        viewModelScope.launch {
            repository.ensureInitialized()
        }
        adController.preloadRewardedAd()
    }

    fun selectRealm(realm: Realm) {
        soundManager.play(SoundCue.TAP)
        _selectedRealm.value = realm
    }

    fun selectCategoryFilter(category: PuzzleCategory?) {
        soundManager.play(SoundCue.TAP)
        _selectedCategoryFilter.value = category
    }

    fun clearStatusToast() {
        _statusToast.value = null
    }

    fun startLevel(levelId: Int) {
        val level = PuzzleCatalog.getLevel(levelId)
        _selectedRealm.value = level.realm
        launchPuzzle(level)
    }

    fun startDailyChallenge() {
        val today = (hubState.value as? HubUiState.Ready)?.snapshot?.todaySnapshot
            ?: com.example.data.local.LocalDayClock.currentDay()
        val dailyLevel = PuzzleCatalog.generateDailyChallenge(today.epochDay)
        launchPuzzle(dailyLevel)
    }

    fun restartCurrentPuzzle() {
        val current = _activeGame.value?.level ?: return
        soundManager.play(SoundCue.TAP)
        launchPuzzle(current)
    }

    fun exitPuzzle() {
        timerJob?.cancel()
        memoryPreviewJob?.cancel()
        _activeGame.value = null
    }

    fun pausePuzzle() {
        val current = _activeGame.value ?: return
        if (current.outcome != null || current.isFailed || current.isPaused) return
        soundManager.play(SoundCue.TAP)
        memoryPreviewJob?.cancel()
        _activeGame.update { it?.copy(isPaused = true, activeFlashPad = null) }
    }

    fun resumePuzzle() {
        val current = _activeGame.value ?: return
        if (!current.isPaused) return
        soundManager.play(SoundCue.TAP)
        _activeGame.update { it?.copy(isPaused = false) }
        if (current.memoryPhase == MemoryPhase.PREVIEW &&
            (current.level.content is PuzzleContent.MemoryMatrix ||
                current.level.content is PuzzleContent.MemorySequence)
        ) {
            runMemoryPreview(current.level)
        }
    }

    private fun launchPuzzle(level: PuzzleLevel) {
        timerJob?.cancel()
        memoryPreviewJob?.cancel()

        val initialState = when (val content = level.content) {
            is PuzzleContent.LogicGridToggle -> ActiveGameState(
                level = level,
                beaconLit = content.initialLit,
                remainingOptimalMoves = content.solutionMoves.toSet()
            )
            is PuzzleContent.NumberMagicGrid -> {
                val firstBlank = content.initialCells.indexOfFirst { it == null }.takeIf { it >= 0 }
                ActiveGameState(
                    level = level,
                    magicCells = content.initialCells,
                    selectedMagicCellIndex = firstBlank
                )
            }
            is PuzzleContent.MemoryMatrix,
            is PuzzleContent.MemorySequence -> ActiveGameState(
                level = level,
                memoryPhase = MemoryPhase.PREVIEW
            )
            else -> ActiveGameState(level = level)
        }

        _activeGame.value = initialState
        startTimerLoop()
        if (level.content is PuzzleContent.MemoryMatrix || level.content is PuzzleContent.MemorySequence) {
            runMemoryPreview(level)
        }
    }

    private fun startTimerLoop() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1_000L)
                val state = _activeGame.value ?: break
                if (!state.isPaused && !state.isFailed && state.outcome == null) {
                    _activeGame.update { it?.copy(elapsedSeconds = it.elapsedSeconds + 1) }
                }
            }
        }
    }

    private fun runMemoryPreview(level: PuzzleLevel) {
        memoryPreviewJob?.cancel()
        memoryPreviewJob = viewModelScope.launch {
            when (val content = level.content) {
                is PuzzleContent.MemoryMatrix -> {
                    _activeGame.update { it?.copy(memoryPhase = MemoryPhase.PREVIEW) }
                    soundManager.play(SoundCue.MEMORY_FLASH)
                    delay(content.previewMillis)
                    _activeGame.update { it?.copy(memoryPhase = MemoryPhase.RECALL) }
                }
                is PuzzleContent.MemorySequence -> {
                    _activeGame.update {
                        it?.copy(
                            memoryPhase = MemoryPhase.PREVIEW,
                            activeFlashPad = null,
                            sequenceProgressIndex = 0
                        )
                    }
                    delay(350L)
                    for (pad in content.sequence) {
                        _activeGame.update { it?.copy(activeFlashPad = pad) }
                        soundManager.play(SoundCue.MEMORY_FLASH)
                        delay(content.stepMillis)
                        _activeGame.update { it?.copy(activeFlashPad = null) }
                        delay(160L)
                    }
                    _activeGame.update { it?.copy(memoryPhase = MemoryPhase.RECALL) }
                }
                else -> Unit
            }
        }
    }

    // --- Board Interactions ---

    fun onToggleBeaconCell(index: Int) {
        val state = _activeGame.value ?: return
        val content = state.level.content as? PuzzleContent.LogicGridToggle ?: return
        if (state.isPaused || state.outcome != null || state.isFailed) return

        val updated = state.beaconLit.toMutableList()
        LogicPuzzleBank.toggleCross(updated, content.gridSize, index)
        val nextRemaining = state.remainingOptimalMoves.toMutableSet()
        if (!nextRemaining.add(index)) {
            nextRemaining.remove(index)
        }

        val solved = updated.all { it }
        soundManager.play(if (solved) SoundCue.CORRECT else SoundCue.TAP)

        _activeGame.update {
            it?.copy(
                beaconLit = updated,
                remainingOptimalMoves = nextRemaining,
                movesUsed = it.movesUsed + 1,
                highlightedHintCell = null,
                feedbackBanner = null
            )
        }

        if (solved) {
            completeActivePuzzle()
        }
    }

    fun onSelectOptionAnswer(optionIndex: Int) {
        val state = _activeGame.value ?: return
        if (state.isPaused || state.outcome != null || state.isFailed) return
        if (optionIndex in state.eliminatedOptionIndices) return

        val isCorrect = when (val content = state.level.content) {
            is PuzzleContent.LogicDeduction -> optionIndex == content.correctIndex
            is PuzzleContent.NumberSequence -> content.options.getOrNull(optionIndex) == content.correctAnswer
            is PuzzleContent.PatternVisual -> optionIndex == content.correctIndex
            else -> false
        }

        if (isCorrect) {
            soundManager.play(SoundCue.CORRECT)
            _activeGame.update {
                it?.copy(
                    selectedOptionIndex = optionIndex,
                    movesUsed = it.movesUsed + 1,
                    feedbackBanner = null
                )
            }
            completeActivePuzzle()
        } else {
            soundManager.play(SoundCue.WRONG)
            val nextMistakes = state.mistakesMade + 1
            val failed = nextMistakes >= 3
            _activeGame.update {
                it?.copy(
                    eliminatedOptionIndices = it.eliminatedOptionIndices + optionIndex,
                    movesUsed = it.movesUsed + 1,
                    mistakesMade = nextMistakes,
                    isFailed = failed,
                    feedbackBanner = if (failed) {
                        "Out of attempts! Try the puzzle again."
                    } else {
                        "Not quite — ${3 - nextMistakes} attempt(s) remaining."
                    }
                )
            }
        }
    }

    fun onSelectMagicCell(index: Int) {
        val state = _activeGame.value ?: return
        val content = state.level.content as? PuzzleContent.NumberMagicGrid ?: return
        if (state.isPaused || state.outcome != null || state.isFailed) return
        if (content.initialCells.getOrNull(index) != null) return // Locked clue cell
        soundManager.play(SoundCue.TAP)
        _activeGame.update { it?.copy(selectedMagicCellIndex = index, feedbackBanner = null) }
    }

    fun onEnterMagicNumber(number: Int) {
        val state = _activeGame.value ?: return
        val content = state.level.content as? PuzzleContent.NumberMagicGrid ?: return
        val targetIndex = state.selectedMagicCellIndex ?: return
        if (state.isPaused || state.outcome != null || state.isFailed) return

        val updatedCells = state.magicCells.toMutableList()
        updatedCells[targetIndex] = number
        soundManager.play(SoundCue.TAP)

        // Advance selection to next empty cell if any
        val nextBlank = updatedCells.indices.firstOrNull { idx ->
            content.initialCells[idx] == null && updatedCells[idx] == null
        } ?: targetIndex

        val allFilled = updatedCells.none { it == null }
        if (allFilled) {
            val size = content.gridSize
            val rowsValid = (0 until size).all { r ->
                (0 until size).sumOf { c -> updatedCells[r * size + c] ?: 0 } == content.rowTargets[r]
            }
            val colsValid = (0 until size).all { c ->
                (0 until size).sumOf { r -> updatedCells[r * size + c] ?: 0 } == content.colTargets[c]
            }
            if (rowsValid && colsValid) {
                soundManager.play(SoundCue.CORRECT)
                _activeGame.update {
                    it?.copy(
                        magicCells = updatedCells,
                        movesUsed = it.movesUsed + 1,
                        feedbackBanner = null
                    )
                }
                completeActivePuzzle()
                return
            } else {
                soundManager.play(SoundCue.WRONG)
                _activeGame.update {
                    it?.copy(
                        magicCells = updatedCells,
                        selectedMagicCellIndex = targetIndex,
                        movesUsed = it.movesUsed + 1,
                        mistakesMade = it.mistakesMade + 1,
                        feedbackBanner = "Check your row & column sums!"
                    )
                }
                return
            }
        }

        _activeGame.update {
            it?.copy(
                magicCells = updatedCells,
                selectedMagicCellIndex = nextBlank,
                movesUsed = it.movesUsed + 1,
                feedbackBanner = null
            )
        }
    }

    fun onClearMagicCell() {
        val state = _activeGame.value ?: return
        val content = state.level.content as? PuzzleContent.NumberMagicGrid ?: return
        val targetIndex = state.selectedMagicCellIndex ?: return
        if (content.initialCells.getOrNull(targetIndex) != null) return
        val updated = state.magicCells.toMutableList()
        updated[targetIndex] = null
        soundManager.play(SoundCue.TAP)
        _activeGame.update { it?.copy(magicCells = updated, feedbackBanner = null) }
    }

    fun onTapMemoryMatrixCell(index: Int) {
        val state = _activeGame.value ?: return
        val content = state.level.content as? PuzzleContent.MemoryMatrix ?: return
        if (state.isPaused || state.outcome != null || state.isFailed) return
        if (state.memoryPhase != MemoryPhase.RECALL) return
        if (index in state.foundMemoryIndices) return

        if (index in content.targetIndices) {
            val newFound = state.foundMemoryIndices + index
            val allFound = newFound.size == content.targetIndices.size
            soundManager.play(if (allFound) SoundCue.CORRECT else SoundCue.TAP)
            _activeGame.update {
                it?.copy(
                    foundMemoryIndices = newFound,
                    movesUsed = it.movesUsed + 1,
                    hintMemoryIndex = if (it.hintMemoryIndex == index) null else it.hintMemoryIndex,
                    wrongMemoryIndex = null,
                    feedbackBanner = null
                )
            }
            if (allFound) {
                completeActivePuzzle()
            }
        } else {
            soundManager.play(SoundCue.WRONG)
            val nextMistakes = state.mistakesMade + 1
            val failed = nextMistakes >= content.maxMistakes
            _activeGame.update {
                it?.copy(
                    mistakesMade = nextMistakes,
                    movesUsed = it.movesUsed + 1,
                    wrongMemoryIndex = index,
                    isFailed = failed,
                    feedbackBanner = if (failed) {
                        "Memory broken! Give it another shot."
                    } else {
                        "Wrong tile! ${content.maxMistakes - nextMistakes} heart(s) left."
                    }
                )
            }
        }
    }

    fun onTapMemorySequencePad(padIndex: Int) {
        val state = _activeGame.value ?: return
        val content = state.level.content as? PuzzleContent.MemorySequence ?: return
        if (state.isPaused || state.outcome != null || state.isFailed) return
        if (state.memoryPhase != MemoryPhase.RECALL) return

        val expectedPad = content.sequence.getOrNull(state.sequenceProgressIndex) ?: return
        if (padIndex == expectedPad) {
            val nextStep = state.sequenceProgressIndex + 1
            val completed = nextStep >= content.sequence.size
            soundManager.play(if (completed) SoundCue.CORRECT else SoundCue.MEMORY_FLASH)
            _activeGame.update {
                it?.copy(
                    sequenceProgressIndex = nextStep,
                    movesUsed = it.movesUsed + 1,
                    activeFlashPad = padIndex,
                    feedbackBanner = null
                )
            }
            viewModelScope.launch {
                delay(180L)
                _activeGame.update { it?.copy(activeFlashPad = null) }
            }
            if (completed) {
                completeActivePuzzle()
            }
        } else {
            soundManager.play(SoundCue.WRONG)
            val nextMistakes = state.mistakesMade + 1
            val failed = nextMistakes >= content.maxMistakes
            _activeGame.update {
                it?.copy(
                    mistakesMade = nextMistakes,
                    movesUsed = it.movesUsed + 1,
                    wrongMemoryIndex = padIndex,
                    isFailed = failed,
                    feedbackBanner = if (failed) {
                        "Sequence lost! Try again."
                    } else {
                        "Wrong rune! ${content.maxMistakes - nextMistakes} chance left."
                    }
                )
            }
        }
    }

    fun requestHint() {
        val state = _activeGame.value ?: return
        if (state.isPaused || state.outcome != null || state.isFailed) return

        viewModelScope.launch {
            val consumed = repository.useHint()
            if (!consumed) {
                soundManager.play(SoundCue.WRONG)
                _statusToast.value = "Need 1 Hint or ${BrainQuestRepository.HINT_COIN_COST} Coins for a hint!"
                return@launch
            }
            soundManager.play(SoundCue.HINT)

            when (val content = state.level.content) {
                is PuzzleContent.LogicGridToggle -> {
                    val nextCell = state.remainingOptimalMoves.firstOrNull()
                    _activeGame.update {
                        it?.copy(
                            hintsUsed = it.hintsUsed + 1,
                            highlightedHintCell = nextCell,
                            hintMessage = if (nextCell != null) {
                                "Tap the glowing cyan beacon tile!"
                            } else {
                                content.hintText
                            }
                        )
                    }
                }
                is PuzzleContent.LogicDeduction -> {
                    val wrongAvailable = content.options.indices.firstOrNull {
                        it != content.correctIndex && it !in state.eliminatedOptionIndices
                    }
                    _activeGame.update {
                        it?.copy(
                            hintsUsed = it.hintsUsed + 1,
                            eliminatedOptionIndices = if (wrongAvailable != null) {
                                it.eliminatedOptionIndices + wrongAvailable
                            } else it.eliminatedOptionIndices,
                            hintMessage = content.hintText
                        )
                    }
                }
                is PuzzleContent.NumberSequence -> {
                    val wrongAvailable = content.options.indices.firstOrNull {
                        content.options[it] != content.correctAnswer && it !in state.eliminatedOptionIndices
                    }
                    _activeGame.update {
                        it?.copy(
                            hintsUsed = it.hintsUsed + 1,
                            eliminatedOptionIndices = if (wrongAvailable != null) {
                                it.eliminatedOptionIndices + wrongAvailable
                            } else it.eliminatedOptionIndices,
                            hintMessage = content.hintText
                        )
                    }
                }
                is PuzzleContent.NumberMagicGrid -> {
                    val targetIdx = state.selectedMagicCellIndex
                        ?.takeIf {
                            content.initialCells[it] == null &&
                                state.magicCells.getOrNull(it) != content.solutionCells[it]
                        }
                        ?: content.initialCells.indices.firstOrNull { idx ->
                            content.initialCells[idx] == null &&
                                state.magicCells.getOrNull(idx) != content.solutionCells[idx]
                        }
                        ?: -1
                    if (targetIdx >= 0) {
                        val updated = state.magicCells.toMutableList()
                        val correctValue = content.solutionCells[targetIdx]
                        updated[targetIdx] = correctValue
                        _activeGame.update {
                            it?.copy(
                                hintsUsed = it.hintsUsed + 1,
                                magicCells = updated,
                                hintMessage = "Revealed cell value: $correctValue. ${content.hintText}"
                            )
                        }
                        val size = content.gridSize
                        val allFilled = updated.none { it == null }
                        if (allFilled) {
                            val rowsValid = (0 until size).all { r ->
                                (0 until size).sumOf { c -> updated[r * size + c] ?: 0 } == content.rowTargets[r]
                            }
                            val colsValid = (0 until size).all { c ->
                                (0 until size).sumOf { r -> updated[r * size + c] ?: 0 } == content.colTargets[c]
                            }
                            if (rowsValid && colsValid) {
                                completeActivePuzzle()
                            }
                        }
                    }
                }
                is PuzzleContent.MemoryMatrix -> {
                    val nextUnfound = content.targetIndices.firstOrNull { it !in state.foundMemoryIndices }
                    _activeGame.update {
                        it?.copy(
                            hintsUsed = it.hintsUsed + 1,
                            hintMemoryIndex = nextUnfound,
                            hintMessage = if (nextUnfound != null) {
                                "One hidden star tile is shimmering in gold!"
                            } else content.hintText
                        )
                    }
                }
                is PuzzleContent.MemorySequence -> {
                    val nextPad = content.sequence.getOrNull(state.sequenceProgressIndex)
                    _activeGame.update {
                        it?.copy(
                            hintsUsed = it.hintsUsed + 1,
                            activeFlashPad = nextPad,
                            hintMessage = "Watch the glowing pad for your next step!"
                        )
                    }
                }
                is PuzzleContent.PatternVisual -> {
                    val wrongAvailable = content.options.indices.firstOrNull {
                        it != content.correctIndex && it !in state.eliminatedOptionIndices
                    }
                    _activeGame.update {
                        it?.copy(
                            hintsUsed = it.hintsUsed + 1,
                            eliminatedOptionIndices = if (wrongAvailable != null) {
                                it.eliminatedOptionIndices + wrongAvailable
                            } else it.eliminatedOptionIndices,
                            hintMessage = content.hintText
                        )
                    }
                }
            }
        }
    }

    private fun completeActivePuzzle() {
        val state = _activeGame.value ?: return
        timerJob?.cancel()
        memoryPreviewJob?.cancel()
        viewModelScope.launch {
            val outcome = repository.completeLevel(
                level = state.level,
                elapsedSeconds = state.elapsedSeconds,
                movesUsed = state.movesUsed.coerceAtLeast(1),
                mistakesMade = state.mistakesMade,
                hintsUsed = state.hintsUsed
            )
            soundManager.play(SoundCue.LEVEL_WIN)
            _activeGame.update { it?.copy(outcome = outcome) }
        }
    }

    fun buyHintPack() {
        viewModelScope.launch {
            val ok = repository.buyHintPack()
            if (ok) {
                soundManager.play(SoundCue.REWARD)
                _statusToast.value = "+${BrainQuestRepository.HINT_PACK_SIZE} Hints unlocked!"
            } else {
                soundManager.play(SoundCue.WRONG)
                _statusToast.value = "Need ${BrainQuestRepository.HINT_PACK_COST} Coins for a Hint Pack."
            }
        }
    }

    fun claimMilestone(rewardId: String) {
        val totalStars = (hubState.value as? HubUiState.Ready)?.snapshot?.totalStars ?: 0
        viewModelScope.launch {
            val claimed = repository.claimMilestone(rewardId, totalStars)
            if (claimed) {
                soundManager.play(SoundCue.REWARD)
                _statusToast.value = "Milestone chest claimed!"
            }
        }
    }

    fun toggleSound(enabled: Boolean) {
        viewModelScope.launch {
            repository.setSoundEnabled(enabled)
            soundManager.isEnabled = enabled
            if (enabled) soundManager.play(SoundCue.TAP)
        }
    }

    fun toggleHaptics(enabled: Boolean) {
        viewModelScope.launch {
            repository.setHapticsEnabled(enabled)
        }
    }

    fun toggleDarkTheme(enabled: Boolean) {
        viewModelScope.launch {
            repository.setDarkThemeEnabled(enabled)
        }
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
        memoryPreviewJob?.cancel()
    }

    class Factory(
        private val repository: BrainQuestRepository,
        private val soundManager: SoundEffectManager,
        private val adController: AdRewardController
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return GameHubViewModel(repository, soundManager, adController) as T
        }
    }
}
