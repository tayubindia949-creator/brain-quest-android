package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Backspace
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.PuzzleContent
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalGamePalette
import com.example.ui.viewmodel.ActiveGameState

@Composable
fun LogicBeaconBoard(
    content: PuzzleContent.LogicGridToggle,
    state: ActiveGameState,
    onToggleCell: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalGamePalette.current
    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Light every beacon! Tapping a tile flips its + neighbors.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(16.dp))

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 360.dp),
            contentAlignment = Alignment.Center
        ) {
            val boardWidth = minOf(maxWidth, 340.dp)
            Column(
                modifier = Modifier.width(boardWidth),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                for (r in 0 until content.gridSize) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        for (c in 0 until content.gridSize) {
                            val idx = r * content.gridSize + c
                            val isLit = state.beaconLit.getOrElse(idx) { false }
                            val isHinted = state.highlightedHintCell == idx
                            val tileBg by animateColorAsState(
                                targetValue = when {
                                    isHinted -> palette.cyanContainer
                                    isLit -> palette.goldContainer
                                    else -> palette.tileSurface
                                },
                                label = "beacon_bg_$idx"
                            )
                            val tileBorderColor = when {
                                isHinted -> palette.cyan
                                isLit -> palette.gold
                                else -> palette.tileBorder
                            }
                            val scale by animateFloatAsState(
                                targetValue = if (isLit) 1.02f else 0.98f,
                                animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                                label = "beacon_scale_$idx"
                            )

                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .aspectRatio(1f)
                                    .scale(scale)
                                    .minimumInteractiveComponentSize()
                                    .testTag("beacon_cell_$idx")
                                    .clip(RoundedCornerShape(16.dp))
                                    .clickable { onToggleCell(idx) },
                                shape = RoundedCornerShape(16.dp),
                                color = tileBg,
                                border = BorderStroke(if (isHinted || isLit) 2.5.dp else 1.5.dp, tileBorderColor),
                                shadowElevation = if (isLit) 6.dp else 1.dp
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = if (isLit) Icons.Rounded.LightMode else Icons.Rounded.PowerSettingsNew,
                                        contentDescription = if (isLit) "Beacon $idx lit" else "Beacon $idx unlit",
                                        tint = when {
                                            isHinted -> palette.cyan
                                            isLit -> palette.gold
                                            else -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                                        },
                                        modifier = Modifier.size(if (content.gridSize == 3) 34.dp else 26.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LogicDeductionBoard(
    content: PuzzleContent.LogicDeduction,
    state: ActiveGameState,
    onSelectOption: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalGamePalette.current
    Column(
        modifier = modifier
            .fillMaxWidth()
            .widthIn(max = 560.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = palette.cardSurface,
            border = BorderStroke(1.dp, palette.tileBorder)
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.Bolt,
                        contentDescription = null,
                        tint = palette.cyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = content.titlePrompt,
                        style = MaterialTheme.typography.titleMedium,
                        color = palette.cyan
                    )
                }

                content.clues.forEachIndexed { idx, clue ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = palette.tileSurface
                    ) {
                        Text(
                            text = "${idx + 1}. $clue",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = content.question,
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.gold,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            content.options.forEachIndexed { index, optionText ->
                val isEliminated = index in state.eliminatedOptionIndices
                val isCorrectSelected = state.selectedOptionIndex == index
                val bg by animateColorAsState(
                    targetValue = when {
                        isCorrectSelected -> palette.emeraldContainer
                        isEliminated -> palette.coralContainer.copy(alpha = 0.45f)
                        else -> palette.tileSurface
                    },
                    label = "deduction_opt_$index"
                )
                val border = when {
                    isCorrectSelected -> palette.emerald
                    isEliminated -> palette.coral.copy(alpha = 0.4f)
                    else -> palette.tileBorder
                }

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .testTag("option_button_$index")
                        .clip(RoundedCornerShape(16.dp))
                        .clickable(enabled = !isEliminated) { onSelectOption(index) },
                    shape = RoundedCornerShape(16.dp),
                    color = bg,
                    border = BorderStroke(1.5.dp, border)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${('A' + index)}.  $optionText",
                            style = MaterialTheme.typography.titleSmall,
                            color = if (isEliminated) {
                                MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.45f)
                            } else {
                                MaterialTheme.colorScheme.onSurface
                            }
                        )
                        if (isCorrectSelected) {
                            Icon(
                                imageVector = Icons.Rounded.CheckCircle,
                                contentDescription = "Correct",
                                tint = palette.emerald
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NumberSequenceBoard(
    content: PuzzleContent.NumberSequence,
    state: ActiveGameState,
    onSelectOption: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalGamePalette.current
    Column(
        modifier = modifier
            .fillMaxWidth()
            .widthIn(max = 560.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Text(
            text = content.prompt,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
        )

        Surface(
            shape = RoundedCornerShape(20.dp),
            color = palette.cardSurface,
            border = BorderStroke(1.dp, palette.tileBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically
            ) {
                content.sequenceTokens.forEachIndexed { idx, token ->
                    val isMissing = token == "?"
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = if (isMissing) palette.goldContainer else palette.tileSurface,
                        border = BorderStroke(
                            width = if (isMissing) 2.dp else 1.dp,
                            color = if (isMissing) palette.gold else palette.tileBorder
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(58.dp)
                            .testTag("seq_token_$idx")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = if (isMissing && state.selectedOptionIndex != null) {
                                    content.options[state.selectedOptionIndex].toString()
                                } else token,
                                fontFamily = JetBrainsMonoFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = if (token.length > 2) 16.sp else 20.sp,
                                color = if (isMissing) palette.gold else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }

        // 2x2 option buttons
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            for (rowIdx in 0 until 2) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    for (colIdx in 0 until 2) {
                        val optIdx = rowIdx * 2 + colIdx
                        if (optIdx < content.options.size) {
                            val optVal = content.options[optIdx]
                            val isEliminated = optIdx in state.eliminatedOptionIndices
                            val isCorrect = state.selectedOptionIndex == optIdx
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .minimumInteractiveComponentSize()
                                    .testTag("option_button_$optIdx")
                                    .clip(RoundedCornerShape(18.dp))
                                    .clickable(enabled = !isEliminated) { onSelectOption(optIdx) },
                                shape = RoundedCornerShape(18.dp),
                                color = when {
                                    isCorrect -> palette.emeraldContainer
                                    isEliminated -> palette.coralContainer.copy(alpha = 0.45f)
                                    else -> palette.tileSurface
                                },
                                border = BorderStroke(
                                    1.5.dp,
                                    when {
                                        isCorrect -> palette.emerald
                                        isEliminated -> palette.coral.copy(alpha = 0.4f)
                                        else -> palette.tileBorder
                                    }
                                )
                            ) {
                                Box(
                                    modifier = Modifier.padding(vertical = 18.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = optVal.toString(),
                                        fontFamily = JetBrainsMonoFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 22.sp,
                                        color = if (isEliminated) {
                                            MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                                        } else {
                                            MaterialTheme.colorScheme.onSurface
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NumberMagicGridBoard(
    content: PuzzleContent.NumberMagicGrid,
    state: ActiveGameState,
    onSelectCell: (Int) -> Unit,
    onEnterNumber: (Int) -> Unit,
    onClearCell: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalGamePalette.current
    Column(
        modifier = modifier
            .fillMaxWidth()
            .widthIn(max = 520.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Fill the empty slots so every row and column matches its golden sum.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )

        Surface(
            shape = RoundedCornerShape(22.dp),
            color = palette.cardSurface,
            border = BorderStroke(1.dp, palette.tileBorder),
            modifier = Modifier.widthIn(max = 350.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                for (r in 0 until content.gridSize) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (c in 0 until content.gridSize) {
                            val idx = r * content.gridSize + c
                            val isFixed = content.initialCells[idx] != null
                            val value = state.magicCells.getOrNull(idx)
                            val isSelected = state.selectedMagicCellIndex == idx

                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .aspectRatio(1f)
                                    .minimumInteractiveComponentSize()
                                    .testTag("magic_cell_$idx")
                                    .clip(RoundedCornerShape(14.dp))
                                    .clickable(enabled = !isFixed) { onSelectCell(idx) },
                                shape = RoundedCornerShape(14.dp),
                                color = when {
                                    isFixed -> palette.tileSurface
                                    isSelected -> palette.cyanContainer
                                    value != null -> palette.violetContainer
                                    else -> palette.canvasBottom
                                },
                                border = BorderStroke(
                                    width = if (isSelected) 2.5.dp else 1.5.dp,
                                    color = when {
                                        isSelected -> palette.cyan
                                        isFixed -> palette.tileBorder
                                        else -> palette.violet
                                    }
                                )
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = value?.toString() ?: "?",
                                        fontFamily = JetBrainsMonoFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 22.sp,
                                        color = when {
                                            isFixed -> MaterialTheme.colorScheme.onSurface
                                            value != null -> palette.cyan
                                            else -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.55f)
                                        }
                                    )
                                }
                            }
                        }

                        // Row target badge
                        val rowSum = (0 until content.gridSize).sumOf { c ->
                            state.magicCells.getOrNull(r * content.gridSize + c) ?: 0
                        }
                        val rowMatched = (0 until content.gridSize).all { c ->
                            state.magicCells.getOrNull(r * content.gridSize + c) != null
                        } && rowSum == content.rowTargets[r]

                        SumTargetBadge(
                            target = content.rowTargets[r],
                            matched = rowMatched,
                            modifier = Modifier.weight(0.85f)
                        )
                    }
                }

                // Column targets row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    for (c in 0 until content.gridSize) {
                        val colSum = (0 until content.gridSize).sumOf { r ->
                            state.magicCells.getOrNull(r * content.gridSize + c) ?: 0
                        }
                        val colMatched = (0 until content.gridSize).all { r ->
                            state.magicCells.getOrNull(r * content.gridSize + c) != null
                        } && colSum == content.colTargets[c]

                        SumTargetBadge(
                            target = content.colTargets[c],
                            matched = colMatched,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(modifier = Modifier.weight(0.85f))
                }
            }
        }

        // Number tray
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val rows = content.numberTray.chunked(4)
            rows.forEach { chunk ->
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    chunk.forEach { num ->
                        Surface(
                            modifier = Modifier
                                .size(56.dp)
                                .minimumInteractiveComponentSize()
                                .testTag("tray_num_$num")
                                .clip(RoundedCornerShape(16.dp))
                                .clickable { onEnterNumber(num) },
                            shape = RoundedCornerShape(16.dp),
                            color = palette.tileSurface,
                            border = BorderStroke(1.5.dp, palette.gold.copy(alpha = 0.55f))
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = num.toString(),
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 20.sp,
                                    color = palette.gold
                                )
                            }
                        }
                    }
                }
            }

            Surface(
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("clear_magic_cell_btn")
                    .clip(RoundedCornerShape(14.dp))
                    .clickable(onClick = onClearCell),
                shape = RoundedCornerShape(14.dp),
                color = palette.tileSurface,
                border = BorderStroke(1.dp, palette.tileBorder)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Backspace,
                        contentDescription = "Clear selected cell",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Clear Cell",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun SumTargetBadge(
    target: Int,
    matched: Boolean,
    modifier: Modifier = Modifier
) {
    val palette = LocalGamePalette.current
    Surface(
        modifier = modifier
            .height(44.dp)
            .semantics { contentDescription = "Target sum $target" },
        shape = RoundedCornerShape(12.dp),
        color = if (matched) palette.emeraldContainer else palette.goldContainer,
        border = BorderStroke(1.dp, if (matched) palette.emerald else palette.gold.copy(alpha = 0.6f))
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = "=$target",
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = if (matched) palette.emerald else palette.gold
            )
        }
    }
}
