package com.example.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.MonetizationOn
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.domain.model.GlyphFill
import com.example.domain.model.GlyphShape
import com.example.domain.model.PatternGlyph
import com.example.domain.model.PuzzleCategory
import com.example.ui.theme.LocalGamePalette
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

@Composable
fun CurrencyPillBar(
    coins: Int,
    stars: Int,
    hints: Int,
    onHintPackClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val palette = LocalGamePalette.current
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ResourceChip(
            icon = Icons.Rounded.MonetizationOn,
            value = coins.toString(),
            tint = palette.gold,
            containerColor = palette.goldContainer,
            contentDesc = "$coins coins",
            tag = "hud_coins_pill"
        )
        ResourceChip(
            icon = Icons.Rounded.Star,
            value = stars.toString(),
            tint = palette.gold,
            containerColor = palette.tileSurface,
            contentDesc = "$stars stars earned",
            tag = "hud_stars_pill"
        )
        ResourceChip(
            icon = Icons.Rounded.Lightbulb,
            value = hints.toString(),
            tint = palette.cyan,
            containerColor = palette.cyanContainer,
            contentDesc = "$hints hints available",
            onClick = onHintPackClick,
            tag = "hud_hints_pill"
        )
    }
}

@Composable
fun ResourceChip(
    icon: ImageVector,
    value: String,
    tint: Color,
    containerColor: Color,
    contentDesc: String,
    tag: String,
    onClick: (() -> Unit)? = null
) {
    val palette = LocalGamePalette.current
    Surface(
        shape = RoundedCornerShape(50),
        color = containerColor,
        border = BorderStroke(1.dp, palette.tileBorder.copy(alpha = 0.6f)),
        modifier = Modifier
            .testTag(tag)
            .then(
                if (onClick != null) {
                    Modifier
                        .minimumInteractiveComponentSize()
                        .clip(RoundedCornerShape(50))
                        .clickable(onClick = onClick)
                } else {
                    Modifier
                }
            )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = contentDesc,
                tint = tint,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun CategoryBadge(
    category: PuzzleCategory,
    modifier: Modifier = Modifier
) {
    val palette = LocalGamePalette.current
    val (icon, tint, bg) = when (category) {
        PuzzleCategory.LOGIC -> Triple(Icons.Rounded.Psychology, palette.cyan, palette.cyanContainer)
        PuzzleCategory.NUMBER -> Triple(Icons.Rounded.Calculate, palette.gold, palette.goldContainer)
        PuzzleCategory.MEMORY -> Triple(Icons.Rounded.AutoAwesome, palette.violet, palette.violetContainer)
        PuzzleCategory.PATTERN -> Triple(Icons.Rounded.GridView, palette.emerald, palette.emeraldContainer)
    }
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(50),
        color = bg,
        border = BorderStroke(1.dp, tint.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = category.displayName,
                tint = tint,
                modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = category.displayName,
                style = MaterialTheme.typography.bodySmall,
                color = tint,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

fun categoryIcon(category: PuzzleCategory): ImageVector = when (category) {
    PuzzleCategory.LOGIC -> Icons.Rounded.Psychology
    PuzzleCategory.NUMBER -> Icons.Rounded.Calculate
    PuzzleCategory.MEMORY -> Icons.Rounded.AutoAwesome
    PuzzleCategory.PATTERN -> Icons.Rounded.GridView
}

@Composable
fun StarRatingRow(
    stars: Int,
    maxStars: Int = 3,
    starSize: Dp = 20.dp,
    modifier: Modifier = Modifier
) {
    val palette = LocalGamePalette.current
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 1..maxStars) {
            val earned = i <= stars
            val scale by animateFloatAsState(
                targetValue = if (earned) 1f else 0.88f,
                animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                label = "star_$i"
            )
            Icon(
                imageVector = if (earned) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                contentDescription = if (earned) "Earned star" else "Empty star",
                tint = if (earned) palette.gold else palette.starInactive,
                modifier = Modifier
                    .size(starSize)
                    .scale(scale)
            )
        }
    }
}

@Composable
fun TactilePrimaryButton(
    text: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    containerColor: Color? = null,
    contentColor: Color? = null,
    testTag: String = "primary_action_button"
) {
    val palette = LocalGamePalette.current
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.96f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMedium),
        label = "btn_scale"
    )
    val bg = containerColor ?: palette.gold
    val fg = contentColor ?: Color(0xFF1A1400)

    Surface(
        modifier = modifier
            .scale(scale)
            .minimumInteractiveComponentSize()
            .testTag(testTag)
            .clip(RoundedCornerShape(18.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            ),
        shape = RoundedCornerShape(18.dp),
        color = bg,
        shadowElevation = 6.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = fg,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.titleMedium,
                color = fg,
                fontWeight = FontWeight.ExtraBold
            )
        }
    }
}

@Composable
fun PatternGlyphCanvas(
    glyph: PatternGlyph,
    modifier: Modifier = Modifier
) {
    val palette = LocalGamePalette.current
    val glyphColors = listOf(palette.gold, palette.cyan, palette.coral, palette.emerald)
    val tint = glyphColors[glyph.colorIndex.mod(glyphColors.size)]

    Canvas(modifier = modifier) {
        val count = glyph.count.coerceIn(1, 3)
        val positions = when (count) {
            1 -> listOf(Offset(size.width / 2f, size.height / 2f) to min(size.width, size.height) * 0.34f)
            2 -> listOf(
                Offset(size.width * 0.33f, size.height * 0.5f) to min(size.width, size.height) * 0.21f,
                Offset(size.width * 0.67f, size.height * 0.5f) to min(size.width, size.height) * 0.21f
            )
            else -> listOf(
                Offset(size.width * 0.5f, size.height * 0.30f) to min(size.width, size.height) * 0.17f,
                Offset(size.width * 0.30f, size.height * 0.68f) to min(size.width, size.height) * 0.17f,
                Offset(size.width * 0.70f, size.height * 0.68f) to min(size.width, size.height) * 0.17f
            )
        }

        for ((center, radius) in positions) {
            rotate(degrees = glyph.rotationDeg.toFloat(), pivot = center) {
                drawSingleGlyph(
                    shape = glyph.shape,
                    fillStyle = glyph.fillStyle,
                    color = tint,
                    center = center,
                    radius = radius
                )
            }
        }
    }
}

private fun DrawScope.drawSingleGlyph(
    shape: GlyphShape,
    fillStyle: GlyphFill,
    color: Color,
    center: Offset,
    radius: Float
) {
    val strokeStyle = Stroke(
        width = (radius * 0.22f).coerceAtLeast(3f),
        cap = StrokeCap.Round,
        join = StrokeJoin.Round
    )

    val path = buildShapePath(shape, center, radius)
    when (fillStyle) {
        GlyphFill.SOLID -> {
            if (shape == GlyphShape.CIRCLE) {
                drawCircle(color = color, radius = radius, center = center, style = Fill)
            } else {
                drawPath(path = path, color = color, style = Fill)
            }
        }
        GlyphFill.OUTLINE -> {
            if (shape == GlyphShape.CIRCLE) {
                drawCircle(color = color, radius = radius, center = center, style = strokeStyle)
            } else {
                drawPath(path = path, color = color, style = strokeStyle)
            }
        }
        GlyphFill.DUAL_RING -> {
            if (shape == GlyphShape.CIRCLE) {
                drawCircle(color = color, radius = radius, center = center, style = strokeStyle)
                drawCircle(color = color, radius = radius * 0.45f, center = center, style = Fill)
            } else {
                drawPath(path = path, color = color, style = strokeStyle)
                val innerPath = buildShapePath(shape, center, radius * 0.48f)
                drawPath(path = innerPath, color = color, style = Fill)
            }
        }
    }
}

private fun buildShapePath(shape: GlyphShape, center: Offset, radius: Float): Path {
    val path = Path()
    when (shape) {
        GlyphShape.CIRCLE -> {
            path.addOval(
                androidx.compose.ui.geometry.Rect(
                    offset = Offset(center.x - radius, center.y - radius),
                    size = Size(radius * 2f, radius * 2f)
                )
            )
        }
        GlyphShape.SQUARE -> {
            val half = radius * 0.86f
            path.moveTo(center.x - half, center.y - half)
            path.lineTo(center.x + half, center.y - half)
            path.lineTo(center.x + half, center.y + half)
            path.lineTo(center.x - half, center.y + half)
            path.close()
        }
        GlyphShape.DIAMOND -> {
            path.moveTo(center.x, center.y - radius)
            path.lineTo(center.x + radius * 0.85f, center.y)
            path.lineTo(center.x, center.y + radius)
            path.lineTo(center.x - radius * 0.85f, center.y)
            path.close()
        }
        GlyphShape.TRIANGLE -> {
            for (i in 0 until 3) {
                val angle = -PI / 2.0 + i * (2.0 * PI / 3.0)
                val x = center.x + (radius * cos(angle)).toFloat()
                val y = center.y + (radius * sin(angle)).toFloat()
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
        }
        GlyphShape.HEXAGON -> {
            for (i in 0 until 6) {
                val angle = -PI / 2.0 + i * (PI / 3.0)
                val x = center.x + (radius * cos(angle)).toFloat()
                val y = center.y + (radius * sin(angle)).toFloat()
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
        }
        GlyphShape.STAR -> {
            val points = 5
            for (i in 0 until points * 2) {
                val r = if (i % 2 == 0) radius else radius * 0.45f
                val angle = -PI / 2.0 + i * (PI / points)
                val x = center.x + (r * cos(angle)).toFloat()
                val y = center.y + (r * sin(angle)).toFloat()
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
        }
    }
    return path
}
