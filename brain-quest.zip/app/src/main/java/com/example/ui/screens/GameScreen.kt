package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.MonetizationOn
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.BrainQuestRepository
import com.example.data.local.PlayerProfile
import com.example.domain.model.PuzzleContent
import com.example.ui.components.CategoryBadge
import com.example.ui.components.FailureOverlay
import com.example.ui.components.LogicBeaconBoard
import com.example.ui.components.LogicDeductionBoard
import com.example.ui.components.MemoryMatrixBoard
import com.example.ui.components.MemorySequenceBoard
import com.example.ui.components.NumberMagicGridBoard
import com.example.ui.components.NumberSequenceBoard
import com.example.ui.components.PatternVisualBoard
import com.example.ui.components.PauseOverlay
import com.example.ui.components.VictoryOverlay
import com.example.ui.components.formatTime
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalGamePalette
import com.example.ui.viewmodel.ActiveGameState

@Composable
fun GameScreen(
    gameState: ActiveGameState,
    profile: PlayerProfile,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onRestart: () -> Unit,
    onExit: () -> Unit,
    onNextLevel: (Int) -> Unit,
    onUseHint: () -> Unit,
    onToggleBeacon: (Int) -> Unit,
    onSelectOption: (Int) -> Unit,
    onSelectMagicCell: (Int) -> Unit,
    onEnterMagicNumber: (Int) -> Unit,
    onClearMagicCell: () -> Unit,
    onTapMemoryMatrix: (Int) -> Unit,
    onTapMemorySequence: (Int) -> Unit,
    onToggleSound: (Boolean) -> Unit,
    onToggleHaptics: (Boolean) -> Unit
) {
    val palette = LocalGamePalette.current
    val level = gameState.level

    BackHandler {
        when {
            gameState.outcome != null || gameState.isFailed -> onExit()
            gameState.isPaused -> onResume()
            else -> onPause()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 640.dp)
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top HUD Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = CircleShape,
                    color = palette.tileSurface,
                    border = BorderStroke(1.dp, palette.tileBorder)
                ) {
                    IconButton(
                        onClick = onPause,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("game_pause_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Pause,
                            contentDescription = "Pause game",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = if (level.isDailyChallenge) "Daily Challenge" else "Level ${level.id} / 100",
                        style = MaterialTheme.typography.titleMedium,
                        color = palette.gold
                    )
                    Text(
                        text = level.title,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Surface(
                    shape = RoundedCornerShape(50),
                    color = palette.tileSurface,
                    border = BorderStroke(1.dp, palette.tileBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Timer,
                            contentDescription = "Timer",
                            tint = palette.cyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = formatTime(gameState.elapsedSeconds),
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Category & Metrics Strip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                CategoryBadge(category = level.category)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Moves: ${gameState.movesUsed}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Difficulty ${"★".repeat(level.difficulty)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.gold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Hint or Feedback Banner
            AnimatedVisibility(
                visible = gameState.hintMessage != null || gameState.feedbackBanner != null,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                val isError = gameState.feedbackBanner != null && gameState.hintMessage == null
                val bannerText = gameState.feedbackBanner ?: gameState.hintMessage.orEmpty()
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (isError) palette.coralContainer else palette.cyanContainer,
                    border = BorderStroke(1.dp, if (isError) palette.coral else palette.cyan),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Lightbulb,
                            contentDescription = null,
                            tint = if (isError) palette.coral else palette.cyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = bannerText,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            // Main Puzzle Board Area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                contentAlignment = Alignment.Center
            ) {
                AnimatedContent(
                    targetState = level.id to gameState.movesUsed.coerceAtMost(0),
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "puzzle_board_transition"
                ) { _ ->
                    when (val content = level.content) {
                        is PuzzleContent.LogicGridToggle -> LogicBeaconBoard(
                            content = content,
                            state = gameState,
                            onToggleCell = onToggleBeacon
                        )
                        is PuzzleContent.LogicDeduction -> LogicDeductionBoard(
                            content = content,
                            state = gameState,
                            onSelectOption = onSelectOption
                        )
                        is PuzzleContent.NumberSequence -> NumberSequenceBoard(
                            content = content,
                            state = gameState,
                            onSelectOption = onSelectOption
                        )
                        is PuzzleContent.NumberMagicGrid -> NumberMagicGridBoard(
                            content = content,
                            state = gameState,
                            onSelectCell = onSelectMagicCell,
                            onEnterNumber = onEnterMagicNumber,
                            onClearCell = onClearMagicCell
                        )
                        is PuzzleContent.MemoryMatrix -> MemoryMatrixBoard(
                            content = content,
                            state = gameState,
                            onTapCell = onTapMemoryMatrix
                        )
                        is PuzzleContent.MemorySequence -> MemorySequenceBoard(
                            content = content,
                            state = gameState,
                            onTapPad = onTapMemorySequence
                        )
                        is PuzzleContent.PatternVisual -> PatternVisualBoard(
                            content = content,
                            state = gameState,
                            onSelectOption = onSelectOption
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Bottom Action Bar (Hint & Restart)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onRestart,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("game_restart_button"),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Rounded.Refresh, contentDescription = "Restart level", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Reset")
                }

                Surface(
                    onClick = onUseHint,
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag("game_hint_button"),
                    shape = RoundedCornerShape(16.dp),
                    color = palette.cyanContainer,
                    border = BorderStroke(1.5.dp, palette.cyan)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Lightbulb,
                            contentDescription = "Use hint",
                            tint = palette.cyan,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        if (profile.hintsRemaining > 0) {
                            Text(
                                text = "Use Hint (${profile.hintsRemaining} left)",
                                style = MaterialTheme.typography.labelLarge,
                                color = palette.cyan
                            )
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Hint (${BrainQuestRepository.HINT_COIN_COST}",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = palette.cyan
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Icon(
                                    imageVector = Icons.Rounded.MonetizationOn,
                                    contentDescription = "coins",
                                    tint = palette.gold,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = ")",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = palette.cyan
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (gameState.isPaused) {
        PauseOverlay(
            level = level,
            elapsedSeconds = gameState.elapsedSeconds,
            soundEnabled = profile.soundEnabled,
            hapticsEnabled = profile.hapticsEnabled,
            onToggleSound = onToggleSound,
            onToggleHaptics = onToggleHaptics,
            onResume = onResume,
            onRestart = onRestart,
            onExit = onExit
        )
    }

    gameState.outcome?.let { outcome ->
        val nextId = if (!level.isDailyChallenge && level.id < 100) level.id + 1 else null
        VictoryOverlay(
            level = level,
            outcome = outcome,
            elapsedSeconds = gameState.elapsedSeconds,
            onNextLevel = nextId?.let { id -> { onNextLevel(id) } },
            onReplay = onRestart,
            onExit = onExit
        )
    }

    if (gameState.isFailed) {
        FailureOverlay(
            message = gameState.feedbackBanner ?: "Give this puzzle another try!",
            onRetry = onRestart,
            onExit = onExit
        )
    }
}
