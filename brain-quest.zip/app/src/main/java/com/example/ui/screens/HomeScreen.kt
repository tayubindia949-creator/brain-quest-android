package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CalendarToday
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.PlayerProgressSnapshot
import com.example.domain.model.PuzzleCategory
import com.example.domain.model.Realm
import com.example.domain.model.RewardCatalog
import com.example.ui.components.CategoryBadge
import com.example.ui.components.CurrencyPillBar
import com.example.ui.components.TactilePrimaryButton
import com.example.ui.theme.LocalGamePalette

@Composable
fun HomeScreen(
    snapshot: PlayerProgressSnapshot,
    onContinueQuest: (Int) -> Unit,
    onOpenLevelSelect: () -> Unit,
    onStartDailyChallenge: () -> Unit,
    onOpenRewards: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val palette = LocalGamePalette.current
    val currentLevel = snapshot.highestUnlockedLevel.coerceIn(1, 100)
    val currentRealm = Realm.forLevel(currentLevel)
    val claimableCount = RewardCatalog.milestones.count {
        snapshot.totalStars >= it.requiredStars && it.id !in snapshot.claimedRewardIds
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 640.dp)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Top Resource & Settings Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                CurrencyPillBar(
                    coins = snapshot.profile.coins,
                    stars = snapshot.totalStars,
                    hints = snapshot.profile.hintsRemaining,
                    onHintPackClick = onOpenSettings
                )
                Surface(
                    shape = CircleShape,
                    color = palette.tileSurface,
                    border = BorderStroke(1.dp, palette.tileBorder)
                ) {
                    IconButton(
                        onClick = onOpenSettings,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("home_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Settings,
                            contentDescription = "Settings",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            // Hero Banner Card
            Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(28.dp),
                    color = palette.cardSurface,
                    border = BorderStroke(1.5.dp, palette.tileBorder),
                    shadowElevation = 10.dp
                ) {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Image(
                            painter = painterResource(id = R.drawable.img_quest_hero_banner),
                            contentDescription = "Brain Quest world illustration",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp)
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp)
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            Color(0x330C0F24),
                                            Color(0xCC0C0F24),
                                            Color(0xF50E122B)
                                        )
                                    )
                                )
                        )
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = palette.gold.copy(alpha = 0.2f),
                                border = BorderStroke(1.dp, palette.gold.copy(alpha = 0.55f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.AutoAwesome,
                                        contentDescription = null,
                                        tint = palette.gold,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Realm ${currentRealm.index}: ${currentRealm.title}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = palette.gold,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            Text(
                                text = "Brain Quest",
                                style = MaterialTheme.typography.displaySmall,
                                color = Color.White
                            )
                            Text(
                                text = "Puzzle Adventure • 100 Original Trials",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color(0xFFD5DEF5)
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${snapshot.completedCount} / 100 Cleared",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.cyan,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${snapshot.totalStars} / 300 ★",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.gold,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = { snapshot.completedCount / 100f },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(7.dp)
                                    .clip(RoundedCornerShape(50)),
                                color = palette.gold,
                                trackColor = Color.White.copy(alpha = 0.16f)
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            TactilePrimaryButton(
                                text = if (snapshot.completedCount == 0) {
                                    "Start Level 1"
                                } else {
                                    "Continue Level $currentLevel"
                                },
                                icon = Icons.Rounded.PlayArrow,
                                onClick = { onContinueQuest(currentLevel) },
                                modifier = Modifier.fillMaxWidth(),
                                testTag = "home_continue_button"
                            )
                        }
                    }
                }

            // Daily Challenge Spotlight Card
            Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("home_daily_card")
                        .clip(RoundedCornerShape(24.dp))
                        .clickable(onClick = onStartDailyChallenge),
                    shape = RoundedCornerShape(24.dp),
                    color = palette.cardSurface,
                    border = BorderStroke(
                        1.5.dp,
                        if (snapshot.todayDailyCompleted) palette.emerald else palette.cyan.copy(alpha = 0.65f)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_daily_challenge_art),
                            contentDescription = "Daily Challenge illustration",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(84.dp)
                                .clip(RoundedCornerShape(18.dp))
                        )
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.CalendarToday,
                                    contentDescription = null,
                                    tint = palette.cyan,
                                    modifier = Modifier.size(15.dp)
                                )
                                Text(
                                    text = "Daily Challenge • ${snapshot.todaySnapshot.displayDate}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.cyan,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = if (snapshot.todayDailyCompleted) {
                                    "Today's Trial Solved!"
                                } else {
                                    "Daily Astral Trial"
                                },
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = palette.goldContainer
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.LocalFireDepartment,
                                            contentDescription = "Daily streak",
                                            tint = palette.gold,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text(
                                            text = "${snapshot.profile.dailyStreak}d Streak",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = palette.gold,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Text(
                                    text = if (snapshot.todayDailyCompleted) "Replay" else "+80 Coins • +1 Hint",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (snapshot.todayDailyCompleted) palette.emerald else MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        Icon(
                            imageVector = if (snapshot.todayDailyCompleted) Icons.Rounded.CheckCircle else Icons.Rounded.PlayArrow,
                            contentDescription = "Play Daily Challenge",
                            tint = if (snapshot.todayDailyCompleted) palette.emerald else palette.cyan,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }

            // Level Map & Rewards Tiles
            Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    HomeHubTile(
                        title = "Adventure Map",
                        subtitle = "All 100 Levels",
                        icon = Icons.Rounded.Explore,
                        accent = palette.violet,
                        containerColor = palette.violetContainer,
                        onClick = onOpenLevelSelect,
                        testTag = "home_levels_button",
                        modifier = Modifier.weight(1f)
                    )
                    HomeHubTile(
                        title = "Rewards",
                        subtitle = if (claimableCount > 0) "$claimableCount Chest Ready!" else "Chests & Badges",
                        icon = Icons.Rounded.EmojiEvents,
                        accent = palette.gold,
                        containerColor = palette.goldContainer,
                        badgeCount = claimableCount,
                        onClick = onOpenRewards,
                        testTag = "home_rewards_button",
                        modifier = Modifier.weight(1f)
                    )
                }

            // Puzzle Disciplines Strip
            Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = palette.cardSurface,
                    border = BorderStroke(1.dp, palette.tileBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Four Disciplines of Mastery",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            PuzzleCategory.entries.forEach { category ->
                                CategoryBadge(
                                    category = category,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                        Text(
                            text = "Score: ${snapshot.totalScore} pts • 100% offline playable",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
private fun HomeHubTile(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accent: Color,
    containerColor: Color,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier,
    badgeCount: Int = 0
) {
    val palette = LocalGamePalette.current
    Surface(
        modifier = modifier
            .minimumInteractiveComponentSize()
            .testTag(testTag)
            .clip(RoundedCornerShape(22.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(22.dp),
        color = palette.cardSurface,
        border = BorderStroke(1.5.dp, if (badgeCount > 0) accent else palette.tileBorder)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = containerColor
                ) {
                    Box(
                        modifier = Modifier.padding(10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = accent,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
                if (badgeCount > 0) {
                    Surface(
                        shape = CircleShape,
                        color = accent
                    ) {
                        Text(
                            text = badgeCount.toString(),
                            style = MaterialTheme.typography.labelMedium,
                            color = Color(0xFF1A1400),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (badgeCount > 0) accent else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
