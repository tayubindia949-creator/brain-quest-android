package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Midnight Observatory (Dark-first primary game palette)
val DeepIndigo900 = Color(0xFF0C0F24)
val DeepIndigo800 = Color(0xFF141938)
val DeepIndigo700 = Color(0xFF1D244D)
val DeepIndigo600 = Color(0xFF283166)

val AmberGold = Color(0xFFFFB703)
val AmberGoldLight = Color(0xFFFFD166)
val AmberGoldDark = Color(0xFFC98A00)

val ElectricCyan = Color(0xFF22D3EE)
val ElectricCyanDark = Color(0xFF0891B2)

val SoftViolet = Color(0xFFA78BFA)
val EmeraldSuccess = Color(0xFF10B981)
val CoralError = Color(0xFFFB7185)

val IvoryText = Color(0xFFF8FAFC)
val MutedLavender = Color(0xFFA5B4CE)

// Light mode ("Sunlit Parchment & Royal Cobalt")
val ParchmentBg = Color(0xFFF5F6FA)
val ParchmentCard = Color(0xFFFFFFFF)
val ParchmentElevated = Color(0xFFEAEFF8)
val RoyalIndigo = Color(0xFF2B3582)
val DeepNavyText = Color(0xFF121736)
val SlateMuted = Color(0xFF5A6585)
val WarmGoldAccent = Color(0xFFD97706)
val DeepTealAccent = Color(0xFF0284C7)
