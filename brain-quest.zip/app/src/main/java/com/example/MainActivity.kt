package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ad.NoOpAdRewardController
import com.example.audio.SoundEffectManager
import com.example.data.local.BrainQuestDatabase
import com.example.data.local.BrainQuestRepository
import com.example.data.local.PlayerPreferencesRepository
import com.example.ui.BrainQuestApp
import com.example.ui.viewmodel.GameHubViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val db = BrainQuestDatabase.getInstance(applicationContext)
        val prefs = PlayerPreferencesRepository(applicationContext)
        val repository = BrainQuestRepository(db.brainQuestDao(), prefs)
        val soundManager = SoundEffectManager()
        val adController = NoOpAdRewardController()

        setContent {
            val vm: GameHubViewModel = viewModel(
                factory = GameHubViewModel.Factory(
                    repository = repository,
                    soundManager = soundManager,
                    adController = adController
                )
            )
            BrainQuestApp(viewModel = vm)
        }
    }
}
