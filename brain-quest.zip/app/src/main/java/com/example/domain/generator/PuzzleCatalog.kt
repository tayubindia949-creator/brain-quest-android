package com.example.domain.generator

import com.example.domain.model.PuzzleCategory
import com.example.domain.model.PuzzleContent
import com.example.domain.model.PuzzleLevel
import com.example.domain.model.Realm
import kotlin.random.Random

object PuzzleCatalog {

    private val realmTitles = mapOf(
        Realm.WHISPERING_WOODS to listOf(
            "Mossy Threshold", "Sunlit Path", "Acorn Balance", "Leaf Constellation",
            "Hollow Trunk", "Brook Stones", "Firefly Trail", "Fern Symmetry",
            "Owl's Riddle", "Briar Step", "Dewdrop Echo", "Birch Matrix",
            "Fox Pact", "Pebble Cross", "Canopy Blink", "Petal Sequence",
            "Sapling Grid", "Meadow Sum", "Root Memory", "Woodland Crown"
        ),
        Realm.CRYSTAL_CAVERNS to listOf(
            "Quartz Awakening", "Echoing Shaft", "Prism Vault", "Shard Reflection",
            "Amethyst Switch", "Geode Ladder", "Subterranean Glow", "Facet Cascade",
            "Twin Stalactites", "Mineral Cross", "Luminous Pool", "Opal Matrix",
            "Cavern Cipher", "Ruby Cascade", "Vein Spark", "Sapphire Loop",
            "Grotto Beacon", "Topaz Balance", "Mirror Recall", "Crystal Spire"
        ),
        Realm.CLOCKWORK_CITADEL to listOf(
            "Brass Pendulum", "Sprocket Sync", "Escapement Pulse", "Cogwheel Array",
            "Mainspring Lock", "Gear Ratio", "Piston Rhythm", "Chrono Lattice",
            "Copper Relay", "Balance Wheel", "Steam Signal", "Ratchet Matrix",
            "Vaulted Dial", "Flywheel Sum", "Tourbillon Flash", "Automaton Code",
            "Pendulum Array", "Torque Grid", "Spring Echo", "Citadel Core"
        ),
        Realm.ASTRAL_OBSERVATORY to listOf(
            "Polaris Alignment", "Orbital Drift", "Nebula Pulse", "Eclipse Grid",
            "Starlight Dial", "Comet Arc", "Zenith Recall", "Zodiac Matrix",
            "Solstice Switch", "Parsec Ladder", "Quasar Beat", "Horizon Prism",
            "Lunar Cipher", "Meteor Cross", "Pulsar Chain", "Aurora Lattice",
            "Aether Node", "Parallax Sum", "Supernova Echo", "Celestial Dome"
        ),
        Realm.CROWN_SANCTUM to listOf(
            "Sovereign Gate", "Triad Theorem", "Phantom Spark", "Imperial Lattice",
            "Alchemist Paradox", "Infinity Ratio", "Memory Tempest", "Oracle Matrix",
            "Sanctum Beacon", "Euler Cross", "Synapse Surge", "Prism Crown",
            "Grand Cipher", "Vertex Harmony", "Echo Labyrinth", "Scepter Grid",
            "Obsidian Node", "Apex Progression", "Eternity Recall", "Crown Finale"
        )
    )

    val allLevels: List<PuzzleLevel> by lazy {
        (1..100).map { levelId -> buildLevel(levelId, isDaily = false, customSeed = levelId * 9973L) }
    }

    fun getLevel(levelId: Int): PuzzleLevel {
        return allLevels.getOrNull(levelId - 1) ?: allLevels.first()
    }

    fun generateDailyChallenge(epochDay: Long): PuzzleLevel {
        val seed = epochDay * 31337L + 7919L
        val rng = Random(seed)
        val categories = PuzzleCategory.entries
        val category = categories[(epochDay % categories.size).toInt().coerceIn(0, categories.lastIndex)]
        val difficulty = 3 + rng.nextInt(0, 2) // Solid medium-hard daily challenge (3..4)
        val content = buildContent(
            category = category,
            indexInCategory = (epochDay % 100).toInt(),
            difficulty = difficulty,
            seed = seed
        )
        return PuzzleLevel(
            id = 0,
            realm = Realm.ASTRAL_OBSERVATORY,
            title = "Daily Astral Trial",
            category = category,
            difficulty = difficulty,
            parMoves = parMovesFor(content),
            parTimeSeconds = 45 + difficulty * 10,
            baseCoinReward = 80,
            isDailyChallenge = true,
            content = content
        )
    }

    private fun buildLevel(levelId: Int, isDaily: Boolean, customSeed: Long): PuzzleLevel {
        val realm = Realm.forLevel(levelId)
        val difficulty = realm.index // 1..5
        val category = when ((levelId - 1) % 4) {
            0 -> PuzzleCategory.LOGIC
            1 -> PuzzleCategory.NUMBER
            2 -> PuzzleCategory.MEMORY
            else -> PuzzleCategory.PATTERN
        }
        val indexInCategory = (levelId - 1) / 4 // 0..24
        val titleList = realmTitles[realm].orEmpty()
        val indexInRealm = (levelId - 1) % 20
        val title = titleList.getOrElse(indexInRealm) { "Quest $levelId" }

        val content = buildContent(
            category = category,
            indexInCategory = indexInCategory,
            difficulty = difficulty,
            seed = customSeed
        )

        return PuzzleLevel(
            id = levelId,
            realm = realm,
            title = title,
            category = category,
            difficulty = difficulty,
            parMoves = parMovesFor(content),
            parTimeSeconds = 25 + difficulty * 12,
            baseCoinReward = 15 + difficulty * 5 + (if (indexInRealm == 19) 25 else 0),
            isDailyChallenge = isDaily,
            content = content
        )
    }

    private fun buildContent(
        category: PuzzleCategory,
        indexInCategory: Int,
        difficulty: Int,
        seed: Long
    ): PuzzleContent {
        return when (category) {
            PuzzleCategory.LOGIC -> {
                if (indexInCategory % 2 == 0) {
                    LogicPuzzleBank.buildBeaconGrid(difficulty, seed)
                } else {
                    val deductionIdx = indexInCategory / 2
                    LogicPuzzleBank.buildDeduction(deductionIdx, difficulty, seed)
                }
            }
            PuzzleCategory.NUMBER -> {
                if (indexInCategory % 5 == 1 || indexInCategory % 5 == 3) {
                    NumberAndMemoryBank.buildMagicGrid(difficulty, seed)
                } else {
                    NumberAndMemoryBank.buildNumberSequence(indexInCategory, difficulty, seed)
                }
            }
            PuzzleCategory.MEMORY -> {
                if (indexInCategory % 5 == 1 || indexInCategory % 5 == 3) {
                    NumberAndMemoryBank.buildMemorySequence(difficulty, seed)
                } else {
                    NumberAndMemoryBank.buildMemoryMatrix(difficulty, seed)
                }
            }
            PuzzleCategory.PATTERN -> {
                PatternPuzzleBank.buildPattern(indexInCategory, difficulty, seed)
            }
        }
    }

    private fun parMovesFor(content: PuzzleContent): Int = when (content) {
        is PuzzleContent.LogicGridToggle -> content.solutionMoves.size
        is PuzzleContent.LogicDeduction -> 1
        is PuzzleContent.NumberSequence -> 1
        is PuzzleContent.NumberMagicGrid -> content.initialCells.count { it == null }
        is PuzzleContent.MemoryMatrix -> content.targetIndices.size
        is PuzzleContent.MemorySequence -> content.sequence.size
        is PuzzleContent.PatternVisual -> 1
    }
}
