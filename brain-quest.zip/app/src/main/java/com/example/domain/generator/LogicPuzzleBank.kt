package com.example.domain.generator

import com.example.domain.model.PuzzleContent
import kotlin.random.Random

internal object LogicPuzzleBank {

    fun buildDeduction(variantIndex: Int, difficulty: Int, seed: Long): PuzzleContent.LogicDeduction {
        val rng = Random(seed)
        return when (variantIndex) {
            0 -> PuzzleContent.LogicDeduction(
                titlePrompt = "Three Relic Chests",
                clues = listOf(
                    "Only one chest holds the Sunstone.",
                    "Gold Chest says: \"It is not in Silver.\"",
                    "Silver Chest says: \"It is in Bronze.\"",
                    "Exactly ONE chest speaks the truth."
                ),
                question = "Which chest holds the Sunstone?",
                options = listOf("Gold Chest", "Silver Chest", "Bronze Chest", "None of them"),
                correctIndex = 1,
                hintText = "Test if Bronze has it: then BOTH Gold and Silver tell the truth. That breaks the rule!"
            )
            1 -> PuzzleContent.LogicDeduction(
                titlePrompt = "Forest Lantern Order",
                clues = listOf(
                    "Four lanterns (Amber, Blue, Cyan, Violet) hang in a row left to right.",
                    "Blue is immediately to the left of Violet.",
                    "Amber is at the far right end.",
                    "Cyan is NOT next to Amber."
                ),
                question = "Which lantern is second from the left?",
                options = listOf("Cyan", "Blue", "Violet", "Amber"),
                correctIndex = 1,
                hintText = "Amber is 4th. Cyan cannot be 3rd, and Blue+Violet sit side by side."
            )
            2 -> PuzzleContent.LogicDeduction(
                titlePrompt = "Owl & Fox Pact",
                clues = listOf(
                    "On odd days, Fox tells the truth; on even days, Owl tells the truth.",
                    "Today Fox says: \"Yesterday I told the truth.\"",
                    "Owl says: \"Today is an even day.\""
                ),
                question = "Who is telling the truth today?",
                options = listOf("Only Fox", "Only Owl", "Both of them", "Neither of them"),
                correctIndex = 1,
                hintText = "Fox can never truthfully say \"Yesterday I told the truth\" because Fox alternates days!"
            )
            3 -> PuzzleContent.LogicDeduction(
                titlePrompt = "Cavern Bridge Weights",
                clues = listOf(
                    "A Ruby weighs more than a Sapphire.",
                    "An Emerald weighs less than a Topaz.",
                    "A Sapphire weighs more than a Topaz."
                ),
                question = "Which gem is the lightest?",
                options = listOf("Ruby", "Sapphire", "Topaz", "Emerald"),
                correctIndex = 3,
                hintText = "Chain the inequalities: Ruby > Sapphire > Topaz > Emerald."
            )
            4 -> PuzzleContent.LogicDeduction(
                titlePrompt = "Clockwork Gear Ratio",
                clues = listOf(
                    "Gear A turns 3 times for every 2 turns of Gear B.",
                    "Gear B turns 4 times for every 5 turns of Gear C.",
                    "Gear A completes 12 full turns."
                ),
                question = "How many turns does Gear C complete?",
                options = listOf("8 turns", "10 turns", "12 turns", "15 turns"),
                correctIndex = 1,
                hintText = "If A = 12, B turns (12 ÷ 3) × 2 = 8 times. Then C = (8 ÷ 4) × 5."
            )
            5 -> PuzzleContent.LogicDeduction(
                titlePrompt = "Twin Gatekeepers",
                clues = listOf(
                    "Gatekeeper North always lies. Gatekeeper South always tells the truth.",
                    "You ask one gatekeeper: \"What would the OTHER keeper say is the safe door?\"",
                    "They point to the Left Door."
                ),
                question = "Which door is actually safe?",
                options = listOf("Left Door", "Right Door", "Both are safe", "Cannot be determined"),
                correctIndex = 1,
                hintText = "Both truth-teller quoting a liar AND liar quoting a truth-teller point to the UNSAFE door."
            )
            6 -> PuzzleContent.LogicDeduction(
                titlePrompt = "Astral Sundial",
                clues = listOf(
                    "Starlight reaches Tower 1 every 4 minutes.",
                    "Starlight reaches Tower 2 every 6 minutes.",
                    "Both towers flash together at 00:00."
                ),
                question = "When do both towers flash together for the 3rd time after 00:00?",
                options = listOf("00:24", "00:36", "00:48", "00:18"),
                correctIndex = 1,
                hintText = "LCM(4, 6) = 12 minutes. Count 3 flashes AFTER 00:00: 12, 24, 36."
            )
            7 -> PuzzleContent.LogicDeduction(
                titlePrompt = "Alchemist Flasks",
                clues = listOf(
                    "Flasks Red, Blue, and Green sit in slots 1, 2, and 3.",
                    "Red is not in slot 1.",
                    "Blue is in a higher-numbered slot than Green.",
                    "Green is not in slot 2."
                ),
                question = "Which flask is in slot 2?",
                options = listOf("Red", "Blue", "Green", "Empty"),
                correctIndex = 0,
                hintText = "Green can only be in slot 1 (if Blue > Green). Since Red is not in slot 1, test Red in slot 2."
            )
            else -> buildSymbolAlgebra(difficulty, rng)
        }
    }

    private fun buildSymbolAlgebra(difficulty: Int, rng: Random): PuzzleContent.LogicDeduction {
        val a = rng.nextInt(2 + difficulty, 6 + difficulty * 2)
        val b = rng.nextInt(1 + difficulty, 5 + difficulty * 2)
        val c = rng.nextInt(1, 4 + difficulty)

        return if (difficulty <= 2) {
            val eq1 = a + a
            val eq2 = a + b
            val target = b * c
            val distractors = linkedSetOf(target + a, target - 2, target + 3, (b + 1) * c)
                .filter { it != target && it > 0 }.take(3)
            val options = (distractors + target).shuffled(rng)
            PuzzleContent.LogicDeduction(
                titlePrompt = "Rune Equation",
                clues = listOf(
                    "▲ + ▲ = $eq1",
                    "▲ + ● = $eq2",
                    "◆ = $c"
                ),
                question = "What is the value of ● × ◆ ?",
                options = options.map { it.toString() },
                correctIndex = options.indexOf(target),
                hintText = "First find ▲ = $eq1 ÷ 2 = $a, then solve for ●."
            )
        } else {
            val eq1 = a * 2 + b
            val eq2 = a + b * 2
            val target = a * c - b
            val distractors = linkedSetOf(target + c, target + 2, target - 3, a * c + b)
                .filter { it != target }.take(3)
            val options = (distractors + target).shuffled(rng)
            PuzzleContent.LogicDeduction(
                titlePrompt = "Cipher Balance",
                clues = listOf(
                    "2▲ + ● = $eq1",
                    "▲ + 2● = $eq2",
                    "◆ = $c"
                ),
                question = "What is (▲ × ◆) - ● ?",
                options = options.map { it.toString() },
                correctIndex = options.indexOf(target),
                hintText = "Add the two equations together: 3(▲ + ●) = ${eq1 + eq2}, so ▲ + ● = ${(eq1 + eq2) / 3}."
            )
        }
    }

    fun buildBeaconGrid(difficulty: Int, seed: Long): PuzzleContent.LogicGridToggle {
        val rng = Random(seed)
        val gridSize = if (difficulty <= 3) 3 else 4
        val total = gridSize * gridSize
        val moveCount = when (difficulty) {
            1 -> 2
            2 -> 3
            3 -> 4
            4 -> 4
            else -> 5
        }

        val allIndices = (0 until total).shuffled(rng)
        val solutionMoves = allIndices.take(moveCount)
        val board = MutableList(total) { true }
        for (idx in solutionMoves) {
            toggleCross(board, gridSize, idx)
        }
        // Safety fallback if somehow all lit
        if (board.all { it }) {
            toggleCross(board, gridSize, 0)
            return PuzzleContent.LogicGridToggle(
                gridSize = gridSize,
                initialLit = board,
                solutionMoves = listOf(0),
                hintText = "Tapping a tile flips itself and its up/down/left/right neighbors. Light every tile!"
            )
        }

        return PuzzleContent.LogicGridToggle(
            gridSize = gridSize,
            initialLit = board,
            solutionMoves = solutionMoves,
            hintText = "Each tap toggles a + cross of beacons. Use Hint to spotlight an exact optimal tile!"
        )
    }

    fun toggleCross(board: MutableList<Boolean>, size: Int, index: Int) {
        val row = index / size
        val col = index % size
        val neighbors = listOf(
            row to col,
            (row - 1) to col,
            (row + 1) to col,
            row to (col - 1),
            row to (col + 1)
        )
        for ((r, c) in neighbors) {
            if (r in 0 until size && c in 0 until size) {
                val pos = r * size + c
                board[pos] = !board[pos]
            }
        }
    }
}
