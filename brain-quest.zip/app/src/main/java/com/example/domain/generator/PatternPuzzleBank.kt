package com.example.domain.generator

import com.example.domain.model.GlyphFill
import com.example.domain.model.GlyphShape
import com.example.domain.model.PatternGlyph
import com.example.domain.model.PuzzleContent
import kotlin.random.Random

internal object PatternPuzzleBank {

    fun buildPattern(variantIndex: Int, difficulty: Int, seed: Long): PuzzleContent.PatternVisual {
        val rng = Random(seed)
        val shapes = GlyphShape.entries.shuffled(rng)
        val fills = GlyphFill.entries.shuffled(rng)
        val colors = listOf(0, 1, 2, 3).shuffled(rng)

        val columns: Int
        val fullGrid: List<PatternGlyph>
        val prompt: String
        val hint: String

        when {
            difficulty == 1 -> {
                // 1x4 linear visual progression
                columns = 4
                prompt = "Which geometric glyph completes the sequence?"
                val mode = variantIndex % 2
                if (mode == 0) {
                    // Growing count + alternating fill
                    val shape = shapes[0]
                    val col = colors[0]
                    fullGrid = List(4) { idx ->
                        PatternGlyph(
                            shape = shape,
                            colorIndex = col,
                            fillStyle = fills[idx % 2],
                            rotationDeg = 0,
                            count = idx + 1
                        )
                    }
                    hint = "Count the shapes (1, 2, 3, 4) and notice how the fill alternates."
                } else {
                    // Rotating triangle/diamond/star + cycling color
                    val shape = listOf(GlyphShape.TRIANGLE, GlyphShape.STAR, GlyphShape.HEXAGON)[variantIndex % 3]
                    fullGrid = List(4) { idx ->
                        PatternGlyph(
                            shape = shape,
                            colorIndex = colors[idx % 2],
                            fillStyle = fills[0],
                            rotationDeg = idx * 90,
                            count = 1
                        )
                    }
                    hint = "Each step rotates 90° clockwise and alternates colors."
                }
            }
            difficulty == 2 -> {
                // 2x2 relational matrix
                columns = 2
                prompt = "Find the glyph that completes the 2×2 matrix."
                fullGrid = listOf(
                    PatternGlyph(shapes[0], colors[0], fills[0], 0, 1),
                    PatternGlyph(shapes[1], colors[0], fills[1], 0, 1),
                    PatternGlyph(shapes[0], colors[1], fills[0], 0, 2),
                    PatternGlyph(shapes[1], colors[1], fills[1], 0, 2)
                )
                hint = "Top-to-bottom switches color and doubles the count; left-to-right switches shape and fill."
            }
            else -> {
                // 3x3 Latin square matrix (Realms III, IV, V)
                columns = 3
                prompt = "Deduce the missing glyph in the 3×3 arcane matrix."
                val rowShapes = shapes.take(3)
                val rowColors = colors.take(3)
                val rowFills = fills.take(3)
                val useCountShift = difficulty >= 4
                val useRotationShift = difficulty >= 5

                fullGrid = List(9) { idx ->
                    val r = idx / 3
                    val c = idx % 3
                    PatternGlyph(
                        shape = rowShapes[(r + c) % 3],
                        colorIndex = rowColors[(r + 2 * c) % 3],
                        fillStyle = rowFills[(2 * r + c) % 3],
                        rotationDeg = if (useRotationShift) ((r + c) % 3) * 90 else 0,
                        count = if (useCountShift) ((r + c) % 3) + 1 else 1
                    )
                }
                hint = if (useCountShift) {
                    "Every row and column contains each shape, color, fill, and count (1, 2, 3) exactly once."
                } else {
                    "Every row and column uses each of the 3 shapes, colors, and fills once."
                }
            }
        }

        val answer = fullGrid.last()
        val displayCells = fullGrid.dropLast(1) + listOf(null)

        // Build 3 guaranteed-distinct distractors
        val distractors = linkedSetOf<PatternGlyph>()
        var attempts = 0
        while (distractors.size < 3 && attempts < 40) {
            attempts++
            val mutated = when (attempts % 4) {
                0 -> answer.copy(shape = shapes.first { it != answer.shape })
                1 -> answer.copy(colorIndex = colors.first { it != answer.colorIndex })
                2 -> answer.copy(fillStyle = fills.first { it != answer.fillStyle })
                else -> answer.copy(
                    count = if (answer.count < 3) answer.count + 1 else 1,
                    rotationDeg = (answer.rotationDeg + 90) % 360
                )
            }
            if (mutated != answer) {
                distractors.add(mutated)
            }
        }

        val options = (distractors.take(3) + answer).shuffled(rng)
        return PuzzleContent.PatternVisual(
            prompt = prompt,
            columns = columns,
            cells = displayCells,
            options = options,
            correctIndex = options.indexOf(answer),
            hintText = hint
        )
    }
}
