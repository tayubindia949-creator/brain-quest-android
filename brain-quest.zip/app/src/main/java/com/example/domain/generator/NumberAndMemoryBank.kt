package com.example.domain.generator

import com.example.domain.model.PuzzleContent
import kotlin.random.Random

internal object NumberAndMemoryBank {

    fun buildNumberSequence(levelIndexInCategory: Int, difficulty: Int, seed: Long): PuzzleContent.NumberSequence {
        val rng = Random(seed)
        val seq: List<Int>
        val answer: Int
        val missingPos: Int
        val ruleSummary: String
        val hint: String

        when (difficulty) {
            1 -> {
                val start = rng.nextInt(2, 12)
                val step = rng.nextInt(2, 7)
                if (levelIndexInCategory % 2 == 0) {
                    seq = List(5) { start + it * step }
                    missingPos = 4
                    answer = seq[missingPos]
                    ruleSummary = "Add $step each step"
                    hint = "Look at the difference between adjacent numbers (+$step)."
                } else {
                    val altA = rng.nextInt(2, 5)
                    val altB = rng.nextInt(4, 9)
                    val list = mutableListOf(start)
                    for (i in 1..4) {
                        list.add(list.last() + if (i % 2 == 1) altA else altB)
                    }
                    seq = list
                    missingPos = 4
                    answer = seq[missingPos]
                    ruleSummary = "Alternating +$altA, +$altB"
                    hint = "The jump alternates between +$altA and +$altB."
                }
            }
            2 -> {
                val start = rng.nextInt(1, 8)
                val baseStep = rng.nextInt(1, 4)
                if (levelIndexInCategory % 2 == 0) {
                    // Increasing step: +d, +(d+1), +(d+2)...
                    val list = mutableListOf(start)
                    for (i in 0 until 4) {
                        list.add(list.last() + baseStep + i)
                    }
                    seq = list
                    missingPos = 4
                    answer = seq[missingPos]
                    ruleSummary = "Steps grow by +1 each jump"
                    hint = "Subtract neighbors: the differences increase by 1 every step."
                } else {
                    // Multiplicative or doubled + offset
                    val mult = 2
                    val offset = rng.nextInt(1, 4)
                    val list = mutableListOf(start)
                    repeat(4) { list.add(list.last() * mult + offset) }
                    seq = list
                    missingPos = 4
                    answer = seq[missingPos]
                    ruleSummary = "Multiply by 2, then add $offset"
                    hint = "Try doubling each term and adding a small constant."
                }
            }
            3 -> {
                if (levelIndexInCategory % 2 == 0) {
                    // Shifted Fibonacci
                    val a = rng.nextInt(2, 6)
                    val b = rng.nextInt(3, 8)
                    val list = mutableListOf(a, b)
                    repeat(4) { list.add(list[list.size - 1] + list[list.size - 2]) }
                    seq = list
                    missingPos = 5
                    answer = seq[missingPos]
                    ruleSummary = "Sum of the previous two numbers"
                    hint = "Add two consecutive numbers together to get the next one."
                } else {
                    // Squares + constant
                    val c = rng.nextInt(1, 7)
                    val startN = rng.nextInt(1, 4)
                    seq = List(5) { val n = startN + it; n * n + c }
                    missingPos = 3
                    answer = seq[missingPos]
                    ruleSummary = "Square sequence (n² + $c)"
                    hint = "Compare each term against perfect squares: 1, 4, 9, 16, 25..."
                }
            }
            4 -> {
                if (levelIndexInCategory % 2 == 0) {
                    // Interleaved dual sequences
                    val a0 = rng.nextInt(3, 9)
                    val b0 = rng.nextInt(10, 18)
                    val da = rng.nextInt(3, 6)
                    val db = rng.nextInt(2, 5)
                    seq = listOf(a0, b0, a0 + da, b0 - db, a0 + da * 2, b0 - db * 2)
                    missingPos = 4
                    answer = seq[missingPos]
                    ruleSummary = "Two interwoven progressions"
                    hint = "Look at odd positions (1st, 3rd, 5th) separately from even positions."
                } else {
                    // Triangular or n*(n+1) + c
                    val c = rng.nextInt(1, 6)
                    val startN = rng.nextInt(1, 4)
                    seq = List(5) { val n = startN + it; n * (n + 1) + c }
                    missingPos = 4
                    answer = seq[missingPos]
                    ruleSummary = "n(n + 1) + $c"
                    hint = "Differences grow by +2 each step (4, 6, 8, 10...)."
                }
            }
            else -> {
                if (levelIndexInCategory % 2 == 0) {
                    // Cubes minus offset
                    val c = rng.nextInt(1, 6)
                    seq = List(5) { val n = it + 2; n * n * n - c }
                    missingPos = 3
                    answer = seq[missingPos]
                    ruleSummary = "Cube sequence (n³ - $c)"
                    hint = "Compare values to cubes: 8, 27, 64, 125, 216."
                } else {
                    // Compound alternating *2+1, *2-1
                    val start = rng.nextInt(2, 6)
                    val list = mutableListOf(start)
                    for (i in 1..4) {
                        val prev = list.last()
                        list.add(if (i % 2 == 1) prev * 2 + 1 else prev * 2 - 2)
                    }
                    seq = list
                    missingPos = 4
                    answer = seq[missingPos]
                    ruleSummary = "Alternating (×2 + 1) and (×2 - 2)"
                    hint = "Check how odd jumps and even jumps transform the doubled value."
                }
            }
        }

        val tokens = seq.mapIndexed { idx, value -> if (idx == missingPos) "?" else value.toString() }
        val distractorCandidates = listOf(
            answer + 2,
            answer - 2,
            answer + 4,
            answer - 3,
            answer + 6,
            answer + 1,
            (answer * 1.15).toInt()
        ).filter { it > 0 && it != answer }.distinct()
        val options = (distractorCandidates.take(3) + answer).shuffled(rng)

        return PuzzleContent.NumberSequence(
            prompt = "Find the missing number in the rune sequence.",
            sequenceTokens = tokens,
            options = options,
            correctAnswer = answer,
            ruleSummary = ruleSummary,
            hintText = hint
        )
    }

    fun buildMagicGrid(difficulty: Int, seed: Long): PuzzleContent.NumberMagicGrid {
        val rng = Random(seed)
        val gridSize = if (difficulty == 1) 2 else 3
        val maxVal = when (difficulty) {
            1 -> 7
            2 -> 9
            3 -> 11
            4 -> 13
            else -> 15
        }
        val solution = List(gridSize * gridSize) { rng.nextInt(1, maxVal + 1) }

        val rowTargets = List(gridSize) { r ->
            (0 until gridSize).sumOf { c -> solution[r * gridSize + c] }
        }
        val colTargets = List(gridSize) { c ->
            (0 until gridSize).sumOf { r -> solution[r * gridSize + c] }
        }

        // Choose missing positions with guaranteed unique cascade solvability
        val missingIndices = when {
            gridSize == 2 -> setOf(1, 2)
            difficulty <= 3 -> setOf(0, 4, 8)
            else -> setOf(0, 1, 4, 8)
        }

        val initialCells = solution.mapIndexed { idx, v -> if (idx in missingIndices) null else v }
        val neededValues = missingIndices.map { solution[it] }.toMutableSet()
        var candidate = 1
        while (neededValues.size < 6) {
            val extra = rng.nextInt(1, maxVal + 2)
            neededValues.add(extra)
            candidate++
            if (candidate > 30) break
        }
        val tray = neededValues.sorted()

        return PuzzleContent.NumberMagicGrid(
            gridSize = gridSize,
            initialCells = initialCells,
            solutionCells = solution,
            rowTargets = rowTargets,
            colTargets = colTargets,
            numberTray = tray,
            hintText = "Start with a row or column that has only ONE empty cell—subtract known values from its target sum!"
        )
    }

    fun buildMemoryMatrix(difficulty: Int, seed: Long): PuzzleContent.MemoryMatrix {
        val rng = Random(seed)
        val gridSize = if (difficulty <= 2) 3 else 4
        val total = gridSize * gridSize
        val targetCount = when (difficulty) {
            1 -> 3
            2 -> 4
            3 -> 5
            4 -> 6
            else -> 7
        }
        val targets = (0 until total).shuffled(rng).take(targetCount).sorted()
        val previewMillis = when (difficulty) {
            1 -> 2600L
            2 -> 2400L
            3 -> 2200L
            4 -> 2000L
            else -> 1850L
        }

        return PuzzleContent.MemoryMatrix(
            gridSize = gridSize,
            targetIndices = targets,
            previewMillis = previewMillis,
            maxMistakes = 3,
            hintText = "Picture the glowing tiles as a constellation shape rather than individual squares."
        )
    }

    fun buildMemorySequence(difficulty: Int, seed: Long): PuzzleContent.MemorySequence {
        val rng = Random(seed)
        val padCount = when {
            difficulty <= 2 -> 4
            difficulty <= 4 -> 6
            else -> 9
        }
        val seqLength = when (difficulty) {
            1 -> 3
            2 -> 4
            3 -> 5
            4 -> 6
            else -> 7
        }
        val sequence = List(seqLength) { rng.nextInt(0, padCount) }
        val stepMillis = when (difficulty) {
            1 -> 650L
            2 -> 600L
            3 -> 540L
            4 -> 490L
            else -> 440L
        }

        return PuzzleContent.MemorySequence(
            padCount = padCount,
            sequence = sequence,
            stepMillis = stepMillis,
            maxMistakes = 2,
            hintText = "Chunk the rune flashes into pairs (1-2, 3-4) as they light up."
        )
    }
}
