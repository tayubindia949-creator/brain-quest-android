package com.example.domain.model

enum class PuzzleCategory(val displayName: String) {
    LOGIC("Logic"),
    NUMBER("Number"),
    MEMORY("Memory"),
    PATTERN("Pattern")
}

enum class Realm(
    val index: Int,
    val title: String,
    val subtitle: String,
    val levelRange: IntRange
) {
    WHISPERING_WOODS(1, "Whispering Woods", "Foundations of Thought", 1..20),
    CRYSTAL_CAVERNS(2, "Crystal Caverns", "Reflecting Symmetries", 21..40),
    CLOCKWORK_CITADEL(3, "Clockwork Citadel", "Compound Mechanics", 41..60),
    ASTRAL_OBSERVATORY(4, "Astral Observatory", "Celestial Deductions", 61..80),
    CROWN_SANCTUM(5, "Crown Sanctum", "Grandmaster Trials", 81..100);

    companion object {
        fun forLevel(levelId: Int): Realm =
            entries.firstOrNull { levelId in it.levelRange } ?: WHISPERING_WOODS
    }
}

enum class GlyphShape {
    CIRCLE,
    TRIANGLE,
    SQUARE,
    DIAMOND,
    HEXAGON,
    STAR
}

enum class GlyphFill {
    SOLID,
    OUTLINE,
    DUAL_RING
}

data class PatternGlyph(
    val shape: GlyphShape,
    val colorIndex: Int,
    val fillStyle: GlyphFill,
    val rotationDeg: Int = 0,
    val count: Int = 1
)

sealed interface PuzzleContent {
    val hintText: String

    data class LogicGridToggle(
        val gridSize: Int,
        val initialLit: List<Boolean>,
        val solutionMoves: List<Int>,
        override val hintText: String
    ) : PuzzleContent

    data class LogicDeduction(
        val titlePrompt: String,
        val clues: List<String>,
        val question: String,
        val options: List<String>,
        val correctIndex: Int,
        override val hintText: String
    ) : PuzzleContent

    data class NumberSequence(
        val prompt: String,
        val sequenceTokens: List<String>,
        val options: List<Int>,
        val correctAnswer: Int,
        val ruleSummary: String,
        override val hintText: String
    ) : PuzzleContent

    data class NumberMagicGrid(
        val gridSize: Int,
        val initialCells: List<Int?>,
        val solutionCells: List<Int>,
        val rowTargets: List<Int>,
        val colTargets: List<Int>,
        val numberTray: List<Int>,
        override val hintText: String
    ) : PuzzleContent

    data class MemoryMatrix(
        val gridSize: Int,
        val targetIndices: List<Int>,
        val previewMillis: Long,
        val maxMistakes: Int,
        override val hintText: String
    ) : PuzzleContent

    data class MemorySequence(
        val padCount: Int,
        val sequence: List<Int>,
        val stepMillis: Long,
        val maxMistakes: Int,
        override val hintText: String
    ) : PuzzleContent

    data class PatternVisual(
        val prompt: String,
        val columns: Int,
        val cells: List<PatternGlyph?>,
        val options: List<PatternGlyph>,
        val correctIndex: Int,
        override val hintText: String
    ) : PuzzleContent
}

data class PuzzleLevel(
    val id: Int,
    val realm: Realm,
    val title: String,
    val category: PuzzleCategory,
    val difficulty: Int,
    val parMoves: Int,
    val parTimeSeconds: Int,
    val baseCoinReward: Int,
    val isDailyChallenge: Boolean = false,
    val content: PuzzleContent
)

data class MilestoneReward(
    val id: String,
    val title: String,
    val description: String,
    val requiredStars: Int,
    val coinReward: Int,
    val hintReward: Int
)

data class AchievementBadge(
    val id: String,
    val title: String,
    val description: String,
    val isUnlocked: Boolean,
    val progressLabel: String
)

object RewardCatalog {
    val milestones: List<MilestoneReward> = listOf(
        MilestoneReward("star_15", "Spark Seeker", "Earn 15 total stars", 15, 60, 1),
        MilestoneReward("star_30", "Lantern Bearer", "Earn 30 total stars", 30, 100, 2),
        MilestoneReward("star_60", "Crystal Scholar", "Earn 60 total stars", 60, 150, 2),
        MilestoneReward("star_100", "Chrono Tactician", "Earn 100 total stars", 100, 220, 3),
        MilestoneReward("star_150", "Astral Voyager", "Earn 150 total stars", 150, 300, 4),
        MilestoneReward("star_225", "Sanctum Sage", "Earn 225 total stars", 225, 450, 5),
        MilestoneReward("star_300", "Grand Luminary", "Master all 300 stars", 300, 1000, 10)
    )
}
