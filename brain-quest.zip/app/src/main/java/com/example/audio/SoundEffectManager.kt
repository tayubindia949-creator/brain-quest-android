package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

enum class SoundCue {
    TAP,
    CORRECT,
    WRONG,
    HINT,
    LEVEL_WIN,
    REWARD,
    MEMORY_FLASH
}

/**
 * Original procedural synthesizer using Android AudioTrack.
 * Generates clean, copyright-free harmonic chimes completely offline.
 */
class SoundEffectManager {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    @Volatile
    var isEnabled: Boolean = true

    fun play(cue: SoundCue) {
        if (!isEnabled) return
        scope.launch {
            runCatching {
                when (cue) {
                    SoundCue.TAP -> playNotes(listOf(660.0 to 45))
                    SoundCue.MEMORY_FLASH -> playNotes(listOf(523.25 to 70))
                    SoundCue.CORRECT -> playNotes(listOf(523.25 to 75, 659.25 to 95))
                    SoundCue.WRONG -> playNotes(listOf(220.0 to 110, 185.0 to 130))
                    SoundCue.HINT -> playNotes(listOf(783.99 to 80, 1046.50 to 130))
                    SoundCue.REWARD -> playNotes(listOf(880.0 to 65, 1174.66 to 110))
                    SoundCue.LEVEL_WIN -> playNotes(
                        listOf(523.25 to 80, 659.25 to 80, 783.99 to 90, 1046.50 to 190)
                    )
                }
            }
        }
    }

    private fun playNotes(notes: List<Pair<Double, Int>>) {
        val sampleRate = 22050
        val totalSamples = notes.sumOf { (sampleRate * it.second) / 1000 }
        if (totalSamples <= 0) return

        val pcm = ShortArray(totalSamples)
        var offset = 0
        for ((freq, durationMs) in notes) {
            val count = (sampleRate * durationMs) / 1000
            for (i in 0 until count) {
                val t = i.toDouble() / sampleRate
                val env = exp(-5.5 * (i.toDouble() / count)) *
                    (if (i < 60) i / 60.0 else 1.0)
                val wave = 0.72 * sin(2.0 * PI * freq * t) + 0.28 * sin(4.0 * PI * freq * t)
                val sample = (wave * env * 0.35 * Short.MAX_VALUE).toInt()
                    .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                if (offset + i < pcm.size) {
                    pcm[offset + i] = sample.toShort()
                }
            }
            offset += count
        }

        val bufferBytes = pcm.size * 2
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bufferBytes)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()

        try {
            track.write(pcm, 0, pcm.size)
            track.play()
            val sleepMs = (totalSamples * 1000L / sampleRate) + 40L
            Thread.sleep(sleepMs)
        } finally {
            runCatching {
                track.stop()
                track.release()
            }
        }
    }
}
