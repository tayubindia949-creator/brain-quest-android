package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "level_progress")
data class LevelProgressEntity(
    @PrimaryKey val levelId: Int,
    val isUnlocked: Boolean,
    val isCompleted: Boolean,
    val bestStars: Int,
    val bestScore: Int,
    val bestTimeSeconds: Int?,
    val attempts: Int,
    val updatedAtEpochMs: Long
)

@Entity(tableName = "daily_challenges")
data class DailyChallengeEntity(
    @PrimaryKey val dateIso: String,
    val epochDay: Long,
    val completed: Boolean,
    val starsEarned: Int,
    val score: Int,
    val completedAtEpochMs: Long
)

@Entity(tableName = "claimed_rewards")
data class ClaimedRewardEntity(
    @PrimaryKey val rewardId: String,
    val claimedAtEpochMs: Long
)
