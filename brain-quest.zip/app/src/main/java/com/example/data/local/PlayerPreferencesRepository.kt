package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.playerDataStore: DataStore<Preferences> by preferencesDataStore(name = "brain_quest_prefs")

data class PlayerProfile(
    val coins: Int = 150,
    val hintsRemaining: Int = 3,
    val soundEnabled: Boolean = true,
    val hapticsEnabled: Boolean = true,
    val darkThemeEnabled: Boolean = true,
    val dailyStreak: Int = 0,
    val lastDailyEpochDay: Long = -1L,
    val lastDailyDateIso: String = ""
)

class PlayerPreferencesRepository(private val context: Context) {

    private object Keys {
        val COINS = intPreferencesKey("coins")
        val HINTS = intPreferencesKey("hints_remaining")
        val SOUND = booleanPreferencesKey("sound_enabled")
        val HAPTICS = booleanPreferencesKey("haptics_enabled")
        val DARK_THEME = booleanPreferencesKey("dark_theme_enabled")
        val DAILY_STREAK = intPreferencesKey("daily_streak")
        val LAST_DAILY_EPOCH_DAY = stringPreferencesKey("last_daily_epoch_day")
        val LAST_DAILY_DATE_ISO = stringPreferencesKey("last_daily_date_iso")
    }

    val playerProfileFlow: Flow<PlayerProfile> = context.playerDataStore.data.map { prefs ->
        PlayerProfile(
            coins = prefs[Keys.COINS] ?: 150,
            hintsRemaining = prefs[Keys.HINTS] ?: 3,
            soundEnabled = prefs[Keys.SOUND] ?: true,
            hapticsEnabled = prefs[Keys.HAPTICS] ?: true,
            darkThemeEnabled = prefs[Keys.DARK_THEME] ?: true,
            dailyStreak = prefs[Keys.DAILY_STREAK] ?: 0,
            lastDailyEpochDay = prefs[Keys.LAST_DAILY_EPOCH_DAY]?.toLongOrNull() ?: -1L,
            lastDailyDateIso = prefs[Keys.LAST_DAILY_DATE_ISO] ?: ""
        )
    }

    suspend fun addCoinsAndHints(coinsDelta: Int, hintsDelta: Int) {
        context.playerDataStore.edit { prefs ->
            val currentCoins = prefs[Keys.COINS] ?: 150
            val currentHints = prefs[Keys.HINTS] ?: 3
            prefs[Keys.COINS] = (currentCoins + coinsDelta).coerceAtLeast(0)
            prefs[Keys.HINTS] = (currentHints + hintsDelta).coerceAtLeast(0)
        }
    }

    suspend fun consumeHint(hintCostInCoins: Int): Boolean {
        var success = false
        context.playerDataStore.edit { prefs ->
            val currentHints = prefs[Keys.HINTS] ?: 3
            val currentCoins = prefs[Keys.COINS] ?: 150
            when {
                currentHints > 0 -> {
                    prefs[Keys.HINTS] = currentHints - 1
                    success = true
                }
                currentCoins >= hintCostInCoins -> {
                    prefs[Keys.COINS] = currentCoins - hintCostInCoins
                    success = true
                }
            }
        }
        return success
    }

    suspend fun buyHintPack(packCount: Int, totalCoinCost: Int): Boolean {
        var purchased = false
        context.playerDataStore.edit { prefs ->
            val currentCoins = prefs[Keys.COINS] ?: 150
            val currentHints = prefs[Keys.HINTS] ?: 3
            if (currentCoins >= totalCoinCost) {
                prefs[Keys.COINS] = currentCoins - totalCoinCost
                prefs[Keys.HINTS] = currentHints + packCount
                purchased = true
            }
        }
        return purchased
    }

    suspend fun recordDailyStreak(epochDay: Long, dateIso: String) {
        context.playerDataStore.edit { prefs ->
            val prevDay = prefs[Keys.LAST_DAILY_EPOCH_DAY]?.toLongOrNull() ?: -1L
            val prevStreak = prefs[Keys.DAILY_STREAK] ?: 0
            val newStreak = when {
                prevDay == epochDay -> prevStreak.coerceAtLeast(1)
                prevDay == epochDay - 1L -> prevStreak + 1
                else -> 1
            }
            prefs[Keys.DAILY_STREAK] = newStreak
            prefs[Keys.LAST_DAILY_EPOCH_DAY] = epochDay.toString()
            prefs[Keys.LAST_DAILY_DATE_ISO] = dateIso
        }
    }

    suspend fun setSoundEnabled(enabled: Boolean) {
        context.playerDataStore.edit { it[Keys.SOUND] = enabled }
    }

    suspend fun setHapticsEnabled(enabled: Boolean) {
        context.playerDataStore.edit { it[Keys.HAPTICS] = enabled }
    }

    suspend fun setDarkThemeEnabled(enabled: Boolean) {
        context.playerDataStore.edit { it[Keys.DARK_THEME] = enabled }
    }
}
