package com.example.data.local

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

data class DaySnapshot(
    val epochDay: Long,
    val dateIso: String,
    val displayDate: String
)

object LocalDayClock {
    fun currentDay(): DaySnapshot {
        val localCal = Calendar.getInstance()
        val year = localCal.get(Calendar.YEAR)
        val month = localCal.get(Calendar.MONTH)
        val day = localCal.get(Calendar.DAY_OF_MONTH)

        val utcMidnight = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
            clear()
            set(year, month, day, 0, 0, 0)
        }
        val epochDay = utcMidnight.timeInMillis / 86_400_000L

        val isoFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val displayFmt = SimpleDateFormat("EEE, MMM d", Locale.US)
        return DaySnapshot(
            epochDay = epochDay,
            dateIso = isoFmt.format(localCal.time),
            displayDate = displayFmt.format(localCal.time)
        )
    }
}
