package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        LevelProgressEntity::class,
        DailyChallengeEntity::class,
        ClaimedRewardEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class BrainQuestDatabase : RoomDatabase() {
    abstract fun brainQuestDao(): BrainQuestDao

    companion object {
        @Volatile
        private var INSTANCE: BrainQuestDatabase? = null

        fun getInstance(context: Context): BrainQuestDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    BrainQuestDatabase::class.java,
                    "brain_quest_offline.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
