package com.example.data.local

import com.example.domain.generator.PuzzleCatalog
import com.example.domain.model.AchievementBadge
import com.example.domain.model.PuzzleCategory
import com.example.domain.model.PuzzleLevel
import com.example.domain.model.RewardCatalog
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlin.math.max

data class LevelCompletionOutcome(
    val starsEarned: Int,
    val score: Int,
    val coinsEarned: Int,
    val hintsEarned: Int,
    val isFirstClear: Boolean,
    val nextLevelUnlocked: Int?
)

data class PlayerProgressSnapshot(
    val profile: PlayerProfile,
    val levelStates: Map<Int, LevelProgressEntity>,
    val totalStars: Int,
    val completedCount: Int,
    val highestUnlockedLevel: Int,
    val totalScore: Int,
    val todaySnapshot: DaySnapshot,
    val todayDailyCompleted: Boolean,
    val dailyHistory: List<DailyChallengeEntity>,
    val claimedRewardIds: Set<String>,
    val badges: List<AchievementBadge>
)

class BrainQuestRepository(
    private val dao: BrainQuestDao,
    private val preferences: PlayerPreferencesRepository
) {
    companion object {
        const val HINT_COIN_COST = 25
        const val HINT_PACK_COST = 60
        const val HINT_PACK_SIZE = 3
    }

    suspend fun ensureInitialized() {
        val now = System.currentTimeMillis()
        val initial = (1..100).map { id ->
            LevelProgressEntity(
                levelId = id,
                isUnlocked = id == 1,
                isCompleted = false,
                bestStars = 0,
                bestScore = 0,
                bestTimeSeconds = null,
                attempts = 0,
                updatedAtEpochMs = now
            )
        }
        dao.insertAllIgnore(initial)
    }

    fun observeSnapshot(): Flow<PlayerProgressSnapshot> {
        return combine(
            preferences.playerProfileFlow,
            dao.observeAllLevelProgress(),
            dao.observeDailyChallenges(),
            dao.observeClaimedRewards()
        ) { profile, levels, dailies, claimed ->
            val levelMap = levels.associateBy { it.levelId }
            val totalStars = levels.sumOf { it.bestStars }
            val completedCount = levels.count { it.isCompleted }
            val highestUnlocked = levels.filter { it.isUnlocked }.maxOfOrNull { it.levelId } ?: 1
            val totalScore = levels.sumOf { it.bestScore } + dailies.sumOf { it.score }

            val today = LocalDayClock.currentDay()
            val todayDone = dailies.any { it.dateIso == today.dateIso && it.completed }
            val claimedSet = claimed.map { it.rewardId }.toSet()

            val badges = buildAchievementBadges(
                levelMap = levelMap,
                totalStars = totalStars,
                completedCount = completedCount,
                streak = profile.dailyStreak,
                dailyCount = dailies.count { it.completed }
            )

            PlayerProgressSnapshot(
                profile = profile,
                levelStates = levelMap,
                totalStars = totalStars,
                completedCount = completedCount,
                highestUnlockedLevel = highestUnlocked,
                totalScore = totalScore,
                todaySnapshot = today,
                todayDailyCompleted = todayDone,
                dailyHistory = dailies,
                claimedRewardIds = claimedSet,
                badges = badges
            )
        }
    }

    suspend fun completeLevel(
        level: PuzzleLevel,
        elapsedSeconds: Int,
        movesUsed: Int,
        mistakesMade: Int,
        hintsUsed: Int
    ): LevelCompletionOutcome {
        val now = System.currentTimeMillis()
        val stars = calculateStars(level, elapsedSeconds, movesUsed, mistakesMade, hintsUsed)
        val score = calculateScore(level, stars, elapsedSeconds, mistakesMade, hintsUsed)

        if (level.isDailyChallenge) {
            val today = LocalDayClock.currentDay()
            val existing = dao.getDailyChallenge(today.dateIso)
            val alreadyDone = existing?.completed == true
            val coinsEarned = if (alreadyDone) 15 else level.baseCoinReward
            val hintsEarned = if (alreadyDone) 0 else 1

            dao.upsertDailyChallenge(
                DailyChallengeEntity(
                    dateIso = today.dateIso,
                    epochDay = today.epochDay,
                    completed = true,
                    starsEarned = max(existing?.starsEarned ?: 0, stars),
                    score = max(existing?.score ?: 0, score),
                    completedAtEpochMs = now
                )
            )
            if (!alreadyDone) {
                preferences.recordDailyStreak(today.epochDay, today.dateIso)
            }
            preferences.addCoinsAndHints(coinsEarned, hintsEarned)

            return LevelCompletionOutcome(
                starsEarned = stars,
                score = score,
                coinsEarned = coinsEarned,
                hintsEarned = hintsEarned,
                isFirstClear = !alreadyDone,
                nextLevelUnlocked = null
            )
        }

        val current = dao.getLevelProgress(level.id)
        val isFirstClear = current?.isCompleted != true
        val prevBestStars = current?.bestStars ?: 0
        val starImprovement = (stars - prevBestStars).coerceAtLeast(0)

        val coinsEarned = when {
            isFirstClear -> level.baseCoinReward + stars * 5
            starImprovement > 0 -> starImprovement * 10
            else -> 5 // replay participation reward
        }
        val bonusHint = if (isFirstClear && level.id % 10 == 0) 1 else 0

        dao.upsertLevelProgress(
            LevelProgressEntity(
                levelId = level.id,
                isUnlocked = true,
                isCompleted = true,
                bestStars = max(prevBestStars, stars),
                bestScore = max(current?.bestScore ?: 0, score),
                bestTimeSeconds = current?.bestTimeSeconds?.let { minOf(it, elapsedSeconds) } ?: elapsedSeconds,
                attempts = (current?.attempts ?: 0) + 1,
                updatedAtEpochMs = now
            )
        )

        var unlockedNext: Int? = null
        if (level.id < 100) {
            val nextId = level.id + 1
            val nextEntity = dao.getLevelProgress(nextId)
            if (nextEntity == null || !nextEntity.isUnlocked) {
                dao.upsertLevelProgress(
                    LevelProgressEntity(
                        levelId = nextId,
                        isUnlocked = true,
                        isCompleted = nextEntity?.isCompleted ?: false,
                        bestStars = nextEntity?.bestStars ?: 0,
                        bestScore = nextEntity?.bestScore ?: 0,
                        bestTimeSeconds = nextEntity?.bestTimeSeconds,
                        attempts = nextEntity?.attempts ?: 0,
                        updatedAtEpochMs = now
                    )
                )
                unlockedNext = nextId
            }
        }

        preferences.addCoinsAndHints(coinsEarned, bonusHint)
        return LevelCompletionOutcome(
            starsEarned = stars,
            score = score,
            coinsEarned = coinsEarned,
            hintsEarned = bonusHint,
            isFirstClear = isFirstClear,
            nextLevelUnlocked = unlockedNext
        )
    }

    suspend fun useHint(): Boolean = preferences.consumeHint(HINT_COIN_COST)

    suspend fun buyHintPack(): Boolean = preferences.buyHintPack(HINT_PACK_SIZE, HINT_PACK_COST)

    suspend fun claimMilestone(rewardId: String, totalStars: Int): Boolean {
        val milestone = RewardCatalog.milestones.firstOrNull { it.id == rewardId } ?: return false
        if (totalStars < milestone.requiredStars) return false
        dao.insertClaimedReward(ClaimedRewardEntity(rewardId, System.currentTimeMillis()))
        preferences.addCoinsAndHints(milestone.coinReward, milestone.hintReward)
        return true
    }

    suspend fun grantAdBonusReward(coins: Int, hints: Int) {
        preferences.addCoinsAndHints(coins, hints)
    }

    suspend fun setSoundEnabled(enabled: Boolean) = preferences.setSoundEnabled(enabled)

    suspend fun setHapticsEnabled(enabled: Boolean) = preferences.setHapticsEnabled(enabled)

    suspend fun setDarkThemeEnabled(enabled: Boolean) = preferences.setDarkThemeEnabled(enabled)

    fun calculateStars(
        level: PuzzleLevel,
        elapsedSeconds: Int,
        movesUsed: Int,
        mistakesMade: Int,
        hintsUsed: Int
    ): Int {
        var stars = 3
        if (mistakesMade >= 1 || hintsUsed >= 1 || movesUsed > level.parMoves + 2 || elapsedSeconds > level.parTimeSeconds) {
            stars = 2
        }
        if (mistakesMade >= 2 || hintsUsed >= 2 || movesUsed > level.parMoves + 5 || elapsedSeconds > level.parTimeSeconds * 2) {
            stars = 1
        }
        return stars.coerceIn(1, 3)
    }

    fun calculateScore(
        level: PuzzleLevel,
        stars: Int,
        elapsedSeconds: Int,
        mistakesMade: Int,
        hintsUsed: Int
    ): Int {
        val base = 200 + level.difficulty * 80
        val starBonus = stars * 120
        val speedBonus = ((level.parTimeSeconds - elapsedSeconds).coerceAtLeast(0)) * 4
        val penalty = mistakesMade * 40 + hintsUsed * 30
        return (base + starBonus + speedBonus - penalty).coerceAtLeast(100)
    }

    private fun buildAchievementBadges(
        levelMap: Map<Int, LevelProgressEntity>,
        totalStars: Int,
        completedCount: Int,
        streak: Int,
        dailyCount: Int
    ): List<AchievementBadge> {
        fun completedInCategory(category: PuzzleCategory): Int =
            PuzzleCatalog.allLevels.count { lvl ->
                lvl.category == category && levelMap[lvl.id]?.isCompleted == true
            }

        val logicDone = completedInCategory(PuzzleCategory.LOGIC)
        val numberDone = completedInCategory(PuzzleCategory.NUMBER)
        val memoryDone = completedInCategory(PuzzleCategory.MEMORY)
        val patternDone = completedInCategory(PuzzleCategory.PATTERN)

        return listOf(
            AchievementBadge(
                id = "first_clear",
                title = "First Spark",
                description = "Complete your very first puzzle level",
                isUnlocked = completedCount >= 1,
                progressLabel = "${completedCount.coerceAtMost(1)} / 1"
            ),
            AchievementBadge(
                id = "realm_one",
                title = "Woods Explorer",
                description = "Conquer all 20 Whispering Woods levels",
                isUnlocked = (1..20).all { levelMap[it]?.isCompleted == true },
                progressLabel = "${(1..20).count { levelMap[it]?.isCompleted == true }} / 20"
            ),
            AchievementBadge(
                id = "logic_ace",
                title = "Logic Luminary",
                description = "Solve 10 Logic puzzles",
                isUnlocked = logicDone >= 10,
                progressLabel = "${logicDone.coerceAtMost(10)} / 10"
            ),
            AchievementBadge(
                id = "number_ace",
                title = "Cipher Whisperer",
                description = "Solve 10 Number puzzles",
                isUnlocked = numberDone >= 10,
                progressLabel = "${numberDone.coerceAtMost(10)} / 10"
            ),
            AchievementBadge(
                id = "memory_ace",
                title = "Echo Savant",
                description = "Solve 10 Memory challenges",
                isUnlocked = memoryDone >= 10,
                progressLabel = "${memoryDone.coerceAtMost(10)} / 10"
            ),
            AchievementBadge(
                id = "pattern_ace",
                title = "Prism Seeker",
                description = "Solve 10 Pattern puzzles",
                isUnlocked = patternDone >= 10,
                progressLabel = "${patternDone.coerceAtMost(10)} / 10"
            ),
            AchievementBadge(
                id = "daily_devotee",
                title = "Astral Streak",
                description = "Reach a 3-day Daily Challenge streak",
                isUnlocked = streak >= 3 || dailyCount >= 3,
                progressLabel = "${streak.coerceAtMost(3)} / 3 days"
            ),
            AchievementBadge(
                id = "centurion",
                title = "Brain Quest Master",
                description = "Earn 150 stars across the adventure",
                isUnlocked = totalStars >= 150,
                progressLabel = "${totalStars.coerceAtMost(150)} / 150 ★"
            )
        )
    }
}
