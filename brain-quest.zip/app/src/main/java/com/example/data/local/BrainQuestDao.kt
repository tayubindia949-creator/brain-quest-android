package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface BrainQuestDao {

    @Query("SELECT * FROM level_progress ORDER BY levelId ASC")
    fun observeAllLevelProgress(): Flow<List<LevelProgressEntity>>

    @Query("SELECT * FROM level_progress WHERE levelId = :levelId LIMIT 1")
    suspend fun getLevelProgress(levelId: Int): LevelProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertLevelProgress(entity: LevelProgressEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAllIgnore(entities: List<LevelProgressEntity>)

    @Query("SELECT * FROM daily_challenges ORDER BY epochDay DESC")
    fun observeDailyChallenges(): Flow<List<DailyChallengeEntity>>

    @Query("SELECT * FROM daily_challenges WHERE dateIso = :dateIso LIMIT 1")
    suspend fun getDailyChallenge(dateIso: String): DailyChallengeEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDailyChallenge(entity: DailyChallengeEntity)

    @Query("SELECT * FROM claimed_rewards")
    fun observeClaimedRewards(): Flow<List<ClaimedRewardEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertClaimedReward(entity: ClaimedRewardEntity)
}
