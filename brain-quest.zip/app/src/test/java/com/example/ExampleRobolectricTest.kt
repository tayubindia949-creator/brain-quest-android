package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.ad.NoOpAdRewardController
import com.example.audio.SoundEffectManager
import com.example.data.local.BrainQuestDatabase
import com.example.data.local.BrainQuestRepository
import com.example.data.local.PlayerPreferencesRepository
import com.example.domain.generator.PuzzleCatalog
import com.example.domain.model.PuzzleContent
import com.example.ui.BrainQuestApp
import com.example.ui.viewmodel.GameHubViewModel
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.concurrent.Executor

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createComposeRule()

    private lateinit var context: Context
    private lateinit var database: BrainQuestDatabase
    private lateinit var repository: BrainQuestRepository
    private lateinit var viewModel: GameHubViewModel

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        val directExecutor = Executor { runnable -> runnable.run() }
        database = Room.inMemoryDatabaseBuilder(context, BrainQuestDatabase::class.java)
            .allowMainThreadQueries()
            .setQueryExecutor(directExecutor)
            .setTransactionExecutor(directExecutor)
            .build()
        val prefs = PlayerPreferencesRepository(context)
        repository = BrainQuestRepository(database.brainQuestDao(), prefs)
        runBlocking { repository.ensureInitialized() }
        val soundManager = SoundEffectManager().apply { isEnabled = false }
        viewModel = GameHubViewModel(repository, soundManager, NoOpAdRewardController())
    }

    @After
    fun tearDown() {
        viewModel.exitPuzzle()
        database.close()
    }

    private fun waitForTag(tag: String) {
        composeRule.waitUntil(timeoutMillis = 5_000L) {
            composeRule.onAllNodesWithTag(tag).fetchSemanticsNodes().isNotEmpty()
        }
    }

    @Test
    fun `read app name from context`() {
        val appName = context.getString(R.string.app_name)
        assertEquals("Brain Quest", appName)
    }

    @Test
    fun `cuj navigate home to levels play level 1 pause resume solve and unlock level 2`() {
        composeRule.setContent {
            BrainQuestApp(viewModel = viewModel)
        }
        waitForTag("home_levels_button")
        composeRule.waitForIdle()

        // Home screen displayed
        composeRule.onNodeWithText("Brain Quest").assertIsDisplayed()
        composeRule.onNodeWithTag("home_levels_button").performScrollTo().performClick()
        waitForTag("level_node_1")
        composeRule.waitForIdle()

        // Adventure Map -> tap Level 1
        composeRule.onNodeWithTag("level_node_1").assertIsDisplayed().performClick()
        waitForTag("game_pause_button")
        composeRule.waitForIdle()

        // Pause and Resume
        composeRule.onNodeWithTag("game_pause_button").performClick()
        waitForTag("pause_dialog")
        composeRule.onNodeWithTag("pause_dialog").assertIsDisplayed()
        composeRule.onNodeWithTag("pause_resume_button").performClick()
        composeRule.waitForIdle()

        // Solve Level 1 (LogicGridToggle) using its exact solutionMoves
        val level1Content = PuzzleCatalog.getLevel(1).content as PuzzleContent.LogicGridToggle
        for (move in level1Content.solutionMoves) {
            composeRule.onNodeWithTag("beacon_cell_$move").performScrollTo().performClick()
            composeRule.waitForIdle()
        }

        // Victory dialog appears -> return to map
        waitForTag("victory_dialog")
        composeRule.onNodeWithTag("victory_dialog").assertIsDisplayed()
        composeRule.onNodeWithTag("victory_map_button").performScrollTo().performClick()
        waitForTag("level_node_2")
        composeRule.waitForIdle()

        // Level 2 is now unlocked and playable! Tap Level 2
        composeRule.onNodeWithTag("level_node_2").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Level 2 / 100").assertIsDisplayed()
    }

    @Test
    fun `cuj navigate to rewards screen and back`() {
        composeRule.setContent {
            BrainQuestApp(viewModel = viewModel)
        }
        waitForTag("home_rewards_button")
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("home_rewards_button").performScrollTo().performClick()
        waitForTag("rewards_back_button")
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Star Milestone Chests").assertIsDisplayed()

        composeRule.onNodeWithTag("rewards_back_button").performClick()
        waitForTag("home_continue_button")
        composeRule.onNodeWithTag("home_continue_button").performScrollTo().assertIsDisplayed()
    }
}
