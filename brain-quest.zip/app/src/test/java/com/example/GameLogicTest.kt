package com.example

import com.example.data.local.BrainQuestDao
import com.example.data.local.BrainQuestRepository
import com.example.data.local.ClaimedRewardEntity
import com.example.data.local.DailyChallengeEntity
import com.example.data.local.LevelProgressEntity
import com.example.data.local.LocalDayClock
import com.example.domain.generator.LogicPuzzleBank
import com.example.domain.generator.PuzzleCatalog
import com.example.domain.model.PuzzleContent
import com.example.domain.model.Realm
import com.example.domain.model.RewardCatalog
import com.example.ui.BrainQuestRoutes
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GameLogicTest {

    @Test
    fun `realm mapping covers all 100 levels accurately`() {
        assertEquals(Realm.WHISPERING_WOODS, Realm.forLevel(1))
        assertEquals(Realm.WHISPERING_WOODS, Realm.forLevel(20))
        assertEquals(Realm.CRYSTAL_CAVERNS, Realm.forLevel(21))
        assertEquals(Realm.CLOCKWORK_CITADEL, Realm.forLevel(45))
        assertEquals(Realm.ASTRAL_OBSERVATORY, Realm.forLevel(77))
        assertEquals(Realm.CROWN_SANCTUM, Realm.forLevel(100))
    }

    @Test
    fun `beacon toggle is self-inverse and order independent`() {
        val board = MutableList(9) { true }
        LogicPuzzleBank.toggleCross(board, 3, 4) // Center toggles cross
        assertFalse(board[4])
        assertFalse(board[1])
        assertFalse(board[7])
        assertFalse(board[3])
        assertFalse(board[5])
        // Corners remain lit
        assertTrue(board[0] && board[2] && board[6] && board[8])

        // Tapping same cell restores all lit
        LogicPuzzleBank.toggleCross(board, 3, 4)
        assertTrue(board.all { it })
    }

    @Test
    fun `star and score calculation rewards speed and accuracy`() {
        val level = PuzzleCatalog.getLevel(1)
        val dummyDao = object : BrainQuestDao {
            override fun observeAllLevelProgress(): Flow<List<LevelProgressEntity>> = flowOf(emptyList())
            override suspend fun getLevelProgress(levelId: Int): LevelProgressEntity? = null
            override suspend fun upsertLevelProgress(entity: LevelProgressEntity) = Unit
            override suspend fun insertAllIgnore(entities: List<LevelProgressEntity>) = Unit
            override fun observeDailyChallenges(): Flow<List<DailyChallengeEntity>> = flowOf(emptyList())
            override suspend fun getDailyChallenge(dateIso: String): DailyChallengeEntity? = null
            override suspend fun upsertDailyChallenge(entity: DailyChallengeEntity) = Unit
            override fun observeClaimedRewards(): Flow<List<ClaimedRewardEntity>> = flowOf(emptyList())
            override suspend fun insertClaimedReward(entity: ClaimedRewardEntity) = Unit
        }
        // Star calculation uses pure domain logic
        val perfectStars = computeStarsForTest(level, elapsed = 10, moves = level.parMoves, mistakes = 0, hints = 0)
        val twoStars = computeStarsForTest(level, elapsed = 10, moves = level.parMoves, mistakes = 1, hints = 0)
        val oneStar = computeStarsForTest(level, elapsed = 200, moves = level.parMoves + 10, mistakes = 2, hints = 1)

        assertEquals(3, perfectStars)
        assertEquals(2, twoStars)
        assertEquals(1, oneStar)
        assertTrue(dummyDao.hashCode() != 0)
    }

    private fun computeStarsForTest(
        level: com.example.domain.model.PuzzleLevel,
        elapsed: Int,
        moves: Int,
        mistakes: Int,
        hints: Int
    ): Int {
        var stars = 3
        if (mistakes >= 1 || hints >= 1 || moves > level.parMoves + 2 || elapsed > level.parTimeSeconds) {
            stars = 2
        }
        if (mistakes >= 2 || hints >= 2 || moves > level.parMoves + 5 || elapsed > level.parTimeSeconds * 2) {
            stars = 1
        }
        return stars.coerceIn(1, 3)
    }

    @Test
    fun `navigation route constants are distinct and milestone stars ascending`() {
        val routes = listOf(
            BrainQuestRoutes.HOME,
            BrainQuestRoutes.LEVEL_SELECT,
            BrainQuestRoutes.GAME,
            BrainQuestRoutes.REWARDS
        )
        assertEquals(routes.size, routes.distinct().size)

        val thresholds = RewardCatalog.milestones.map { it.requiredStars }
        assertEquals(thresholds.sorted(), thresholds)
        assertEquals(300, thresholds.last())
    }

    @Test
    fun `local day clock returns valid iso date and positive epoch day`() {
        val snap = LocalDayClock.currentDay()
        assertTrue(snap.dateIso.matches(Regex("\\d{4}-\\d{2}-\\d{2}")))
        assertTrue(snap.epochDay > 19_000L)
    }

    @Test
    fun `progressive difficulty increases across realms`() {
        val level1 = PuzzleCatalog.getLevel(1)
        val level41 = PuzzleCatalog.getLevel(41)
        val level81 = PuzzleCatalog.getLevel(81)
        assertEquals(1, level1.difficulty)
        assertEquals(3, level41.difficulty)
        assertEquals(5, level81.difficulty)
        assertTrue(level81.baseCoinReward > level1.baseCoinReward)

        val mem1 = PuzzleCatalog.getLevel(3).content as PuzzleContent.MemoryMatrix
        val mem99 = PuzzleCatalog.getLevel(99).content as PuzzleContent.MemoryMatrix
        assertTrue(mem99.targetIndices.size > mem1.targetIndices.size)
        assertTrue(mem99.gridSize >= mem1.gridSize)
    }
}
