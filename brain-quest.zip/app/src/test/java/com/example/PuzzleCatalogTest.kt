package com.example

import com.example.domain.generator.LogicPuzzleBank
import com.example.domain.generator.PuzzleCatalog
import com.example.domain.model.PuzzleCategory
import com.example.domain.model.PuzzleContent
import com.example.domain.model.Realm
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PuzzleCatalogTest {

    @Test
    fun `catalog contains exactly 100 unique sequential levels`() {
        val levels = PuzzleCatalog.allLevels
        assertEquals(100, levels.size)
        assertEquals((1..100).toList(), levels.map { it.id })
    }

    @Test
    fun `all 4 categories and 5 realms are evenly represented`() {
        val levels = PuzzleCatalog.allLevels
        for (category in PuzzleCategory.entries) {
            assertEquals(25, levels.count { it.category == category })
        }
        for (realm in Realm.entries) {
            assertEquals(20, levels.count { it.realm == realm })
        }
    }

    @Test
    fun `all 100 puzzles are mathematically valid and solvable`() {
        for (level in PuzzleCatalog.allLevels) {
            assertTrue("Title blank on level ${level.id}", level.title.isNotBlank())
            assertTrue("Hint blank on level ${level.id}", level.content.hintText.isNotBlank())

            when (val content = level.content) {
                is PuzzleContent.LogicGridToggle -> {
                    assertEquals(content.gridSize * content.gridSize, content.initialLit.size)
                    assertFalse("Level ${level.id} already solved initially", content.initialLit.all { it })
                    val board = content.initialLit.toMutableList()
                    for (move in content.solutionMoves) {
                        LogicPuzzleBank.toggleCross(board, content.gridSize, move)
                    }
                    assertTrue("Level ${level.id} BeaconGrid did not solve to all true", board.all { it })
                }

                is PuzzleContent.LogicDeduction -> {
                    assertTrue(content.clues.isNotEmpty())
                    assertEquals(4, content.options.size)
                    assertTrue(content.correctIndex in content.options.indices)
                    assertEquals(4, content.options.distinct().size)
                }

                is PuzzleContent.NumberSequence -> {
                    assertTrue(content.sequenceTokens.contains("?"))
                    assertTrue(content.options.contains(content.correctAnswer))
                    assertEquals(4, content.options.distinct().size)
                }

                is PuzzleContent.NumberMagicGrid -> {
                    val size = content.gridSize
                    assertEquals(size * size, content.initialCells.size)
                    assertEquals(size * size, content.solutionCells.size)
                    for (r in 0 until size) {
                        val rowSum = (0 until size).sumOf { c -> content.solutionCells[r * size + c] }
                        assertEquals("Row $r sum mismatch on level ${level.id}", content.rowTargets[r], rowSum)
                    }
                    for (c in 0 until size) {
                        val colSum = (0 until size).sumOf { r -> content.solutionCells[r * size + c] }
                        assertEquals("Col $c sum mismatch on level ${level.id}", content.colTargets[c], colSum)
                    }
                    content.initialCells.forEachIndexed { idx, v ->
                        if (v == null) {
                            assertTrue(
                                "Tray missing solution value on level ${level.id}",
                                content.numberTray.contains(content.solutionCells[idx])
                            )
                        }
                    }
                }

                is PuzzleContent.MemoryMatrix -> {
                    val total = content.gridSize * content.gridSize
                    assertTrue(content.targetIndices.isNotEmpty())
                    assertTrue(content.targetIndices.all { it in 0 until total })
                    assertEquals(content.targetIndices.size, content.targetIndices.distinct().size)
                }

                is PuzzleContent.MemorySequence -> {
                    assertTrue(content.sequence.isNotEmpty())
                    assertTrue(content.sequence.all { it in 0 until content.padCount })
                }

                is PuzzleContent.PatternVisual -> {
                    assertEquals(4, content.options.size)
                    assertTrue(content.correctIndex in content.options.indices)
                    assertEquals(4, content.options.distinct().size)
                    assertTrue(content.cells.contains(null))
                }
            }
        }
    }

    @Test
    fun `daily challenge generation is deterministic per day and varies across days`() {
        val dayA = PuzzleCatalog.generateDailyChallenge(20_000L)
        val dayASecondCall = PuzzleCatalog.generateDailyChallenge(20_000L)
        val dayB = PuzzleCatalog.generateDailyChallenge(20_001L)

        assertTrue(dayA.isDailyChallenge)
        assertEquals(dayA.category, dayASecondCall.category)
        assertEquals(dayA.content, dayASecondCall.content)
        assertNotEquals(dayA.category, dayB.category)
    }
}
